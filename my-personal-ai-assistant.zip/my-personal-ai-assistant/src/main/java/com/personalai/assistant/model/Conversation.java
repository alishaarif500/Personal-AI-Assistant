package com.personalai.assistant.model;

import java.time.LocalDateTime;

public record Conversation(long id, String title, LocalDateTime createdAt, LocalDateTime updatedAt) {}
