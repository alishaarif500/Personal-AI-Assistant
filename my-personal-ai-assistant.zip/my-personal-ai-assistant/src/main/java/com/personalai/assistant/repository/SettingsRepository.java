package com.personalai.assistant.repository;

import com.personalai.assistant.db.Database;
import com.personalai.assistant.db.DatabaseException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Simple key/value store for user preferences such as the theme. */
public class SettingsRepository {
    private final Database db;

    public SettingsRepository(Database db) { this.db = db; }

    public String get(String key, String def) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT value FROM settings WHERE key=?")) {
            ps.setString(1, key);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : def;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not read settings: " + e.getMessage(), e);
        }
    }

    public void set(String key, String value) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(
                "INSERT INTO settings(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")) {
            ps.setString(1, key);
            ps.setString(2, value);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Could not save settings: " + e.getMessage(), e);
        }
    }
}
