package com.personalai.assistant.service;

/** Thrown when user input is invalid; the message is shown directly to the user. */
public class ValidationException extends RuntimeException {
    public ValidationException(String message) { super(message); }
}
