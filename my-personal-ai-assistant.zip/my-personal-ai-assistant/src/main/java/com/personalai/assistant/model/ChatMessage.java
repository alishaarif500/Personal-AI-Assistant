package com.personalai.assistant.model;

import java.time.LocalDateTime;

public record ChatMessage(long id, long conversationId, Role role, String content, LocalDateTime createdAt) {
    public enum Role {
        USER("user"), ASSISTANT("assistant");
        private final String wire;
        Role(String wire) { this.wire = wire; }
        public String wire() { return wire; }
        public static Role fromWire(String s) { return "assistant".equals(s) ? ASSISTANT : USER; }
    }
}
