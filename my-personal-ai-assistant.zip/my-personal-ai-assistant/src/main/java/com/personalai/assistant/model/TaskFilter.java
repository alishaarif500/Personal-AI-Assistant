package com.personalai.assistant.model;

public enum TaskFilter {
    ALL("All"), PENDING("Pending"), COMPLETED("Completed"), HIGH_PRIORITY("High priority"), TODAY("Today");

    private final String label;
    TaskFilter(String label) { this.label = label; }
    public String label() { return label; }
}
