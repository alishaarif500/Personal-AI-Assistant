package com.personalai.assistant.ui;

import com.personalai.assistant.model.Priority;
import com.personalai.assistant.model.Task;
import com.personalai.assistant.model.TaskFilter;
import com.personalai.assistant.service.TaskService;
import com.personalai.assistant.service.ValidationException;
import com.personalai.assistant.util.Dates;
import com.personalai.assistant.util.Text;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;

/** Task manager: list, filter, search, add, edit, complete, delete. */
public class TaskPanel extends JPanel implements Page {
    private final TaskService service;
    private final JTextField search = new HintTextField("Search tasks…");
    private final VerticalList list = new VerticalList();
    private final JLabel summary = Ui.label(" ", Theme.small(), Theme.MUTED);
    private TaskFilter filter = TaskFilter.ALL;
    private final Timer debounce;

    public TaskPanel(TaskService service) {
        this.service = service;
        setLayout(new BorderLayout(0, 16));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 24, 32));

        ModernButton add = new ModernButton("New task", ModernButton.Kind.PRIMARY).withIcon(Icons.Type.PLUS);
        add.addActionListener(e -> openDialog(null));

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        JPanel header = Ui.pageHeader("Tasks", "Plan your work and tick things off", add);
        header.setAlignmentX(0f);
        top.add(header);
        top.add(Ui.vgap(16));

        JPanel tools = new JPanel(new BorderLayout(16, 0));
        tools.setOpaque(false);
        tools.setAlignmentX(0f);
        search.setToolTipText("Search tasks by title or description");
        RoundedPanel searchBox = Ui.inputBox(search);
        searchBox.setPreferredSize(new java.awt.Dimension(260, 38));
        JPanel searchWrap = new JPanel(new BorderLayout(0, 0));
        searchWrap.setOpaque(false);
        searchWrap.add(searchBox);
        tools.add(searchWrap, BorderLayout.EAST);
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        chips.setOpaque(false);
        ButtonGroup group = new ButtonGroup();
        for (TaskFilter f : TaskFilter.values()) {
            Chip chip = new Chip(f.label());
            chip.setSelected(f == filter);
            chip.addActionListener(e -> { filter = f; refresh(); });
            group.add(chip);
            chips.add(chip);
        }
        tools.add(chips, BorderLayout.CENTER);
        top.add(tools);
        top.add(Ui.vgap(6));
        summary.setAlignmentX(0f);
        top.add(summary);
        add(top, BorderLayout.NORTH);
        add(Ui.scroll(list), BorderLayout.CENTER);

        debounce = new Timer(250, e -> refresh());
        debounce.setRepeats(false);
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { debounce.restart(); }
            @Override public void removeUpdate(DocumentEvent e) { debounce.restart(); }
            @Override public void changedUpdate(DocumentEvent e) { debounce.restart(); }
        });
    }

    @Override public void onShow() { refresh(); }

    private void refresh() {
        list.removeAll();
        try {
            List<Task> tasks = service.list(filter, search.getText());
            LocalDate today = LocalDate.now();
            summary.setText(tasks.size() + (tasks.size() == 1 ? " task" : " tasks"));
            if (tasks.isEmpty()) {
                boolean searching = Text.trimToNull(search.getText()) != null;
                list.add(searching || filter != TaskFilter.ALL
                        ? Ui.emptyState(Icons.Type.SEARCH, "No matching tasks", "Try another filter or search term.")
                        : Ui.emptyState(Icons.Type.TASKS, "No tasks yet", "Click “New task” to add your first one."));
            }
            for (Task t : tasks) {
                list.add(row(t, today));
                list.add(Ui.vgap(8));
            }
        } catch (RuntimeException e) {
            summary.setText(" ");
            list.add(Ui.banner("Could not load tasks: " + e.getMessage(), Theme.DANGER, Theme.DANGER_SOFT));
        }
        list.revalidate();
        list.repaint();
    }

    private JComponent row(Task t, LocalDate today) {
        RowPanel row = new RowPanel();
        row.add(new CheckCircle(t.completed(), () -> toggle(t)), BorderLayout.WEST);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        String title = Ui.escapeHtml(Text.truncate(t.title(), 90));
        JLabel titleLabel = new JLabel(t.completed() ? "<html><s>" + title + "</s></html>" : title);
        titleLabel.setFont(Theme.bold());
        titleLabel.setForeground(t.completed() ? Theme.MUTED : Theme.TEXT);
        titleLabel.setAlignmentX(0f);
        center.add(titleLabel);

        JPanel meta = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        meta.setOpaque(false);
        meta.setAlignmentX(0f);
        meta.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        Color pf = switch (t.priority()) { case HIGH -> Theme.DANGER; case MEDIUM -> Theme.WARNING; case LOW -> Theme.SUCCESS; };
        Color pb = switch (t.priority()) { case HIGH -> Theme.DANGER_SOFT; case MEDIUM -> Theme.WARNING_SOFT; case LOW -> Theme.SUCCESS_SOFT; };
        meta.add(Ui.badge(t.priority().label(), pf, pb));
        if (t.dueDate() != null) {
            boolean overdue = t.isOverdue(today);
            String due = t.dueDate().equals(today) ? "Due today" : overdue ? "Overdue · " + Dates.date(t.dueDate()) : "Due " + Dates.date(t.dueDate());
            meta.add(Ui.label(due, Theme.small(), overdue ? Theme.DANGER : Theme.MUTED));
        }
        if (!t.description().isBlank()) meta.add(Ui.label("· " + Text.truncate(t.description(), 70), Theme.small(), Theme.MUTED));
        center.add(meta);
        row.add(center, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 2, 0));
        actions.setOpaque(false);
        IconButton edit = new IconButton(Icons.Type.EDIT, "Edit task", Theme.ACCENT);
        edit.addActionListener(e -> openDialog(t));
        IconButton del = new IconButton(Icons.Type.TRASH, "Delete task", Theme.DANGER);
        del.addActionListener(e -> delete(t));
        actions.add(edit);
        actions.add(del);
        row.add(actions, BorderLayout.EAST);
        return row;
    }

    private void toggle(Task t) {
        try {
            service.setCompleted(t.id(), !t.completed());
        } catch (RuntimeException e) {
            Ui.message(this, "Could not update task", e.getMessage(), true);
        }
        refresh();
    }

    private void delete(Task t) {
        if (!Ui.confirm(this, "Delete task?", "“" + Text.truncate(t.title(), 60) + "” will be permanently deleted.", "Delete", true)) return;
        try {
            service.delete(t.id());
        } catch (RuntimeException e) {
            Ui.message(this, "Could not delete task", e.getMessage(), true);
        }
        refresh();
    }

    private void openDialog(Task existing) {
        if (new TaskDialog(this, existing).open()) refresh();
    }

    /** Add / edit dialog. */
    private final class TaskDialog extends FormDialog {
        private final Task existing;
        private final JTextField title = new HintTextField("What needs to be done?");
        private final JTextArea description = new HintTextArea(4, 20, "Add details…");
        private final JCheckBox hasDue = new JCheckBox("Set a due date");
        private final JSpinner due;
        private Priority priority;

        TaskDialog(Component parent, Task existing) {
            super(parent, existing == null ? "New task" : "Edit task", existing == null ? "Add task" : "Save changes");
            this.existing = existing;
            this.priority = existing == null ? Priority.MEDIUM : existing.priority();
            LocalDate initialDue = existing != null && existing.dueDate() != null ? existing.dueDate() : LocalDate.now();
            due = dateSpinner(initialDue);

            if (existing != null) {
                title.setText(existing.title());
                description.setText(existing.description());
            }
            addField("Title", Ui.inputBox(title));
            addField("Description (optional)", Ui.textAreaBox(description, 96));

            JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            chips.setOpaque(false);
            ButtonGroup g = new ButtonGroup();
            for (Priority p : Priority.values()) {
                Chip c = new Chip(p.label());
                c.setSelected(p == priority);
                c.addActionListener(e -> priority = p);
                g.add(c);
                chips.add(c);
            }
            addField("Priority", chips);

            hasDue.setOpaque(false);
            hasDue.setFont(Theme.base());
            hasDue.setForeground(Theme.TEXT);
            hasDue.setSelected(existing != null && existing.dueDate() != null);
            due.setEnabled(hasDue.isSelected());
            hasDue.addActionListener(e -> due.setEnabled(hasDue.isSelected()));
            JPanel dueRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
            dueRow.setOpaque(false);
            dueRow.add(hasDue);
            dueRow.add(due);
            addField("Due date", dueRow);
        }

        @Override protected void doSave() throws ParseException {
            LocalDate dueDate = hasDue.isSelected() ? readDate(due) : null;
            if (existing == null) service.create(title.getText(), description.getText(), priority, dueDate);
            else service.update(existing.id(), title.getText(), description.getText(), priority, dueDate);
        }
    }
}
