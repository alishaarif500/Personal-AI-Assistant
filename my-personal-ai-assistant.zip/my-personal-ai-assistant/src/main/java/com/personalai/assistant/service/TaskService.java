package com.personalai.assistant.service;

import com.personalai.assistant.model.Priority;
import com.personalai.assistant.model.Task;
import com.personalai.assistant.model.TaskFilter;
import com.personalai.assistant.repository.TaskRepository;
import com.personalai.assistant.util.Text;

import java.time.LocalDate;
import java.util.List;

public class TaskService {
    public static final int MAX_TITLE = 150;
    public static final int MAX_DESCRIPTION = 2000;

    private final TaskRepository repo;

    public TaskService(TaskRepository repo) { this.repo = repo; }

    public Task create(String title, String description, Priority priority, LocalDate due) {
        String t = validateTitle(title);
        return repo.insert(t, clean(description), priority == null ? Priority.MEDIUM : priority, due);
    }

    public void update(long id, String title, String description, Priority priority, LocalDate due) {
        String t = validateTitle(title);
        if (!repo.update(id, t, clean(description), priority == null ? Priority.MEDIUM : priority, due)) {
            throw new ValidationException("This task no longer exists. It may have been deleted.");
        }
    }

    public void setCompleted(long id, boolean completed) {
        if (!repo.setCompleted(id, completed)) throw new ValidationException("This task no longer exists.");
    }

    public void delete(long id) {
        if (!repo.delete(id)) throw new ValidationException("This task no longer exists.");
    }

    public int deleteCompleted() { return repo.deleteCompleted(); }

    public Task get(long id) { return repo.findById(id); }

    public List<Task> list(TaskFilter filter, String query) {
        return repo.find(filter == null ? TaskFilter.ALL : filter, query, LocalDate.now());
    }

    private static String validateTitle(String title) {
        String t = Text.trimToNull(title);
        if (t == null) throw new ValidationException("Please enter a task title.");
        if (t.length() > MAX_TITLE) throw new ValidationException("The task title is too long (maximum " + MAX_TITLE + " characters).");
        return t;
    }

    private static String clean(String d) {
        String s = d == null ? "" : d.strip();
        if (s.length() > MAX_DESCRIPTION) throw new ValidationException("The description is too long (maximum " + MAX_DESCRIPTION + " characters).");
        return s;
    }
}
