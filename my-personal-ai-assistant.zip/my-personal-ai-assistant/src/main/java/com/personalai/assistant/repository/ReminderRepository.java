package com.personalai.assistant.repository;

import com.personalai.assistant.db.Database;
import com.personalai.assistant.db.DatabaseException;
import com.personalai.assistant.model.Reminder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ReminderRepository {
    private final Database db;

    public ReminderRepository(Database db) { this.db = db; }

    public Reminder insert(String title, String description, LocalDateTime at) {
        LocalDateTime now = LocalDateTime.now().withNano(0);
        String sql = "INSERT INTO reminders(title, description, remind_at, notified, created_at) VALUES (?,?,?,0,?)";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, at.toString());
            ps.setString(4, now.toString());
            ps.executeUpdate();
            return new Reminder(Database.lastInsertId(c), title, description, at, false, now);
        } catch (SQLException e) {
            throw new DatabaseException("Could not save the reminder: " + e.getMessage(), e);
        }
    }

    /** Rescheduling (a changed time) resets the "notified" flag so the reminder fires again; other edits keep it. */
    public boolean update(long id, String title, String description, LocalDateTime at) {
        String sql = "UPDATE reminders SET title=?, description=?, notified=CASE WHEN remind_at=? THEN notified ELSE 0 END, remind_at=? WHERE id=?";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, at.toString());
            ps.setString(4, at.toString());
            ps.setLong(5, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not update the reminder: " + e.getMessage(), e);
        }
    }

    public boolean delete(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM reminders WHERE id=?")) {
            ps.setLong(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not delete the reminder: " + e.getMessage(), e);
        }
    }

    public Reminder findById(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM reminders WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not read the reminder: " + e.getMessage(), e);
        }
    }

    /** All reminders, upcoming (not yet notified) first, then past ones, newest first. */
    public List<Reminder> findAll() {
        return query("SELECT * FROM reminders ORDER BY notified ASC, "
                + "CASE WHEN notified=0 THEN remind_at END ASC, remind_at DESC");
    }

    public List<Reminder> findUpcoming(LocalDateTime from, int limit) {
        List<Reminder> out = new ArrayList<>();
        String sql = "SELECT * FROM reminders WHERE notified=0 AND remind_at >= ? ORDER BY remind_at ASC LIMIT ?";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, from.toString());
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(map(rs));
            }
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not load upcoming reminders: " + e.getMessage(), e);
        }
    }

    public List<Reminder> findDue(LocalDateTime now) {
        List<Reminder> out = new ArrayList<>();
        String sql = "SELECT * FROM reminders WHERE notified=0 AND remind_at <= ? ORDER BY remind_at ASC";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, now.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(map(rs));
            }
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not check reminders: " + e.getMessage(), e);
        }
    }

    /**
     * Atomically flags a reminder as notified. Returns true only for the single caller that
     * actually flipped the flag, which is what prevents duplicate notifications.
     */
    public boolean markNotified(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("UPDATE reminders SET notified=1 WHERE id=? AND notified=0")) {
            ps.setLong(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not update the reminder: " + e.getMessage(), e);
        }
    }

    public int countUpcoming(LocalDateTime from) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM reminders WHERE notified=0 AND remind_at >= ?")) {
            ps.setString(1, from.toString());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not count reminders: " + e.getMessage(), e);
        }
    }

    public int count() {
        try (Connection c = db.connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM reminders")) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            throw new DatabaseException("Could not count reminders: " + e.getMessage(), e);
        }
    }

    private List<Reminder> query(String sql) {
        List<Reminder> out = new ArrayList<>();
        try (Connection c = db.connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) out.add(map(rs));
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not load reminders: " + e.getMessage(), e);
        }
    }

    private Reminder map(ResultSet rs) throws SQLException {
        return new Reminder(rs.getLong("id"), rs.getString("title"), rs.getString("description"),
                LocalDateTime.parse(rs.getString("remind_at")), rs.getInt("notified") == 1,
                LocalDateTime.parse(rs.getString("created_at")));
    }
}
