package com.personalai.assistant.ui;

import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Central place for colours and fonts. Indigo accent on a calm slate palette, with a light and a dark mode. */
public final class Theme {
    public enum Mode { LIGHT, DARK }

    public static Mode mode = Mode.LIGHT;

    public static Color BG, SURFACE, SURFACE_ALT, BORDER, TEXT, MUTED, INPUT_BG;
    public static Color ACCENT, ACCENT_HOVER, ACCENT_SOFT;
    public static Color SUCCESS, SUCCESS_SOFT, WARNING, WARNING_SOFT, DANGER, DANGER_SOFT;
    public static final Color SIDEBAR = new Color(0x0F172A);
    public static final Color SIDEBAR_HOVER = new Color(0x1E293B);
    public static final Color SIDEBAR_ACTIVE = new Color(0x312E81);
    public static final Color SIDEBAR_TEXT = new Color(0xCBD5E1);
    public static Color USER_BUBBLE, ASSISTANT_BUBBLE, ASSISTANT_TEXT;

    private static String family;

    private Theme() {}

    public static void apply(Mode m) {
        mode = m;
        if (m == Mode.DARK) {
            BG = c(0x0B1120); SURFACE = c(0x111A2E); SURFACE_ALT = c(0x18233D); BORDER = c(0x26334F);
            TEXT = c(0xE5E9F2); MUTED = c(0x93A0B8); INPUT_BG = c(0x0D1527);
            ACCENT = c(0x818CF8); ACCENT_HOVER = c(0xA5B4FC); ACCENT_SOFT = c(0x232B57);
            SUCCESS = c(0x34D399); SUCCESS_SOFT = c(0x10332B);
            WARNING = c(0xFBBF24); WARNING_SOFT = c(0x3A2F10);
            DANGER = c(0xF87171); DANGER_SOFT = c(0x3B1A1F);
            USER_BUBBLE = c(0x4F46E5); ASSISTANT_BUBBLE = c(0x1B2845); ASSISTANT_TEXT = TEXT;
        } else {
            BG = c(0xF4F6FB); SURFACE = c(0xFFFFFF); SURFACE_ALT = c(0xF1F5F9); BORDER = c(0xE2E8F0);
            TEXT = c(0x0F172A); MUTED = c(0x64748B); INPUT_BG = c(0xFFFFFF);
            ACCENT = c(0x4F46E5); ACCENT_HOVER = c(0x4338CA); ACCENT_SOFT = c(0xEEF2FF);
            SUCCESS = c(0x059669); SUCCESS_SOFT = c(0xD1FAE5);
            WARNING = c(0xB45309); WARNING_SOFT = c(0xFEF3C7);
            DANGER = c(0xDC2626); DANGER_SOFT = c(0xFEE2E2);
            USER_BUBBLE = c(0x4F46E5); ASSISTANT_BUBBLE = c(0xFFFFFF); ASSISTANT_TEXT = TEXT;
        }
        UIManager.put("Panel.background", new ColorUIResource(BG));
        UIManager.put("OptionPane.background", new ColorUIResource(SURFACE));
        UIManager.put("Spinner.background", new ColorUIResource(INPUT_BG));
        UIManager.put("Spinner.foreground", new ColorUIResource(TEXT));
        UIManager.put("FormattedTextField.background", new ColorUIResource(INPUT_BG));
        UIManager.put("FormattedTextField.foreground", new ColorUIResource(TEXT));
        UIManager.put("FormattedTextField.caretForeground", new ColorUIResource(TEXT));
        UIManager.put("FormattedTextField.selectionBackground", new ColorUIResource(ACCENT));
        UIManager.put("FormattedTextField.selectionForeground", new ColorUIResource(Color.WHITE));
        UIManager.put("ToolTip.background", new ColorUIResource(SURFACE_ALT));
        UIManager.put("ToolTip.foreground", new ColorUIResource(TEXT));
        UIManager.put("swing.boldMetal", Boolean.FALSE);
    }

    private static Color c(int rgb) { return new Color(rgb); }

    private static synchronized String family() {
        if (family == null) {
            Set<String> names = new HashSet<>();
            try {
                names.addAll(Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
            } catch (Exception ignored) {
                // fall through to Dialog
            }
            family = "Dialog";
            for (String f : new String[] {"Segoe UI", "Inter", "SF Pro Text", "Helvetica Neue", "Noto Sans", "DejaVu Sans"}) {
                if (names.contains(f)) { family = f; break; }
            }
        }
        return family;
    }

    public static Font font(int style, float size) { return new Font(family(), style, 1).deriveFont(style, size); }
    public static Font base() { return font(Font.PLAIN, 14f); }
    public static Font bold() { return font(Font.BOLD, 14f); }
    public static Font small() { return font(Font.PLAIN, 12f); }
    public static Font smallBold() { return font(Font.BOLD, 12f); }
    public static Font heading() { return font(Font.BOLD, 26f); }
    public static Font subheading() { return font(Font.BOLD, 17f); }
    public static Font stat() { return font(Font.BOLD, 30f); }
}
