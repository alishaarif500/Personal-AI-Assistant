package com.personalai.assistant.ui;

/** A screen that can refresh its data every time it becomes visible. */
public interface Page {
    void onShow();
}
