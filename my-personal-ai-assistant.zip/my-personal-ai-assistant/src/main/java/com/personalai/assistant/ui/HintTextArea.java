package com.personalai.assistant.ui;

import javax.swing.JTextArea;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/** Text area that shows grey placeholder text while empty. */
public class HintTextArea extends JTextArea {
    private final String hint;

    public HintTextArea(int rows, int cols, String hint) {
        super(rows, cols);
        this.hint = hint;
        getAccessibleContext().setAccessibleDescription(hint);
    }

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getText().isEmpty()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(Theme.MUTED);
            g2.setFont(getFont());
            g2.drawString(hint, getInsets().left, getInsets().top + g2.getFontMetrics().getAscent());
            g2.dispose();
        }
    }
}
