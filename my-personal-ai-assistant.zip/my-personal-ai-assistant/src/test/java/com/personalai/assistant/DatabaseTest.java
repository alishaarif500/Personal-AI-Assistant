package com.personalai.assistant;

import com.personalai.assistant.db.Database;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class DatabaseTest {
    @Test
    void createsFileAndAllTablesOnFirstLaunch(@TempDir Path dir) throws Exception {
        Path file = dir.resolve("nested/folder/assistant.db");
        Database db = new Database(file);
        db.initialize();
        assertTrue(Files.exists(file));
        Set<String> tables = new HashSet<>();
        try (Connection c = db.connect(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT name FROM sqlite_master WHERE type='table'")) {
            while (rs.next()) tables.add(rs.getString(1));
        }
        assertTrue(tables.containsAll(Set.of("tasks", "notes", "reminders", "conversations", "messages", "settings")), tables.toString());
    }

    @Test
    void initializeIsIdempotentAndForeignKeysAreEnforced(@TempDir Path dir) throws Exception {
        Database db = new Database(dir.resolve("a.db"));
        db.initialize();
        db.initialize();
        try (Connection c = db.connect(); Statement st = c.createStatement()) {
            assertThrows(java.sql.SQLException.class, () ->
                    st.executeUpdate("INSERT INTO messages(conversation_id, role, content, created_at) VALUES (999,'user','x','2026-01-01T00:00:00')"));
        }
    }
}
