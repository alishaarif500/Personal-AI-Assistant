package com.personalai.assistant.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;

/** A rounded list row that keeps its natural height inside a vertical list. */
public class RowPanel extends RoundedPanel {
    public RowPanel() {
        super(new BorderLayout(14, 0));
        setAlignmentX(Component.LEFT_ALIGNMENT);
        setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 16, 12, 12));
    }

    @Override public Dimension getMaximumSize() {
        return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
    }
}
