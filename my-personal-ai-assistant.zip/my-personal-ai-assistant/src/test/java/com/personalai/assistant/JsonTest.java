package com.personalai.assistant;

import com.personalai.assistant.util.Json;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JsonTest {
    @Test
    void parsesNestedStructures() {
        var o = Json.asObject(Json.parse(" {\"a\":[1,2.5,{\"b\":null}],\"s\":\"x\\u00e9\\n\",\"t\":true} "));
        assertEquals(3, Json.asArray(o.get("a")).size());
        assertEquals("xé\n", o.get("s"));
        assertEquals(Boolean.TRUE, o.get("t"));
    }

    @Test
    void quoteRoundTrips() {
        String nasty = "line1\nline2 \"quoted\" back\\slash \u0001 unicode: ñ 中";
        assertEquals(nasty, Json.parse(Json.quote(nasty)));
    }

    @Test
    void rejectsGarbage() {
        assertThrows(IllegalArgumentException.class, () -> Json.parse("<html>502 Bad Gateway</html>"));
        assertThrows(IllegalArgumentException.class, () -> Json.parse("{\"a\":"));
    }
}
