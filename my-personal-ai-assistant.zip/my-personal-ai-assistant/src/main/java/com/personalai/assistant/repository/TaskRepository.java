package com.personalai.assistant.repository;

import com.personalai.assistant.db.Database;
import com.personalai.assistant.db.DatabaseException;
import com.personalai.assistant.model.Priority;
import com.personalai.assistant.model.Task;
import com.personalai.assistant.model.TaskFilter;
import com.personalai.assistant.util.Text;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TaskRepository {
    private final Database db;

    public TaskRepository(Database db) { this.db = db; }

    public Task insert(String title, String description, Priority priority, LocalDate due) {
        String sql = "INSERT INTO tasks(title, description, priority, due_date, created_at, status) VALUES (?,?,?,?,?, 'PENDING')";
        LocalDateTime now = LocalDateTime.now().withNano(0);
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, priority.name());
            ps.setString(4, due == null ? null : due.toString());
            ps.setString(5, now.toString());
            ps.executeUpdate();
            return new Task(Database.lastInsertId(c), title, description, priority, due, now, false, null);
        } catch (SQLException e) {
            throw new DatabaseException("Could not save the task: " + e.getMessage(), e);
        }
    }

    public boolean update(long id, String title, String description, Priority priority, LocalDate due) {
        String sql = "UPDATE tasks SET title=?, description=?, priority=?, due_date=? WHERE id=?";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, priority.name());
            ps.setString(4, due == null ? null : due.toString());
            ps.setLong(5, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not update the task: " + e.getMessage(), e);
        }
    }

    public boolean setCompleted(long id, boolean completed) {
        String sql = "UPDATE tasks SET status=?, completed_at=? WHERE id=?";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, completed ? "COMPLETED" : "PENDING");
            ps.setString(2, completed ? LocalDateTime.now().withNano(0).toString() : null);
            ps.setLong(3, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not change the task status: " + e.getMessage(), e);
        }
    }

    public boolean delete(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM tasks WHERE id=?")) {
            ps.setLong(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not delete the task: " + e.getMessage(), e);
        }
    }

    public int deleteCompleted() {
        try (Connection c = db.connect(); Statement st = c.createStatement()) {
            return st.executeUpdate("DELETE FROM tasks WHERE status='COMPLETED'");
        } catch (SQLException e) {
            throw new DatabaseException("Could not delete completed tasks: " + e.getMessage(), e);
        }
    }

    public Task findById(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM tasks WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not read the task: " + e.getMessage(), e);
        }
    }

    public List<Task> find(TaskFilter filter, String query, LocalDate today) {
        StringBuilder sql = new StringBuilder("SELECT * FROM tasks WHERE 1=1");
        List<String> args = new ArrayList<>();
        switch (filter) {
            case PENDING -> sql.append(" AND status='PENDING'");
            case COMPLETED -> sql.append(" AND status='COMPLETED'");
            case HIGH_PRIORITY -> sql.append(" AND priority='HIGH'");
            case TODAY -> { sql.append(" AND due_date = ?"); args.add(today.toString()); }
            default -> { }
        }
        String q = Text.trimToNull(query);
        if (q != null) {
            sql.append(" AND (title LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\')");
            String like = "%" + Text.likeEscape(q) + "%";
            args.add(like);
            args.add(like);
        }
        sql.append(" ORDER BY status ASC, (due_date IS NULL), due_date ASC,"
                + " CASE priority WHEN 'HIGH' THEN 0 WHEN 'MEDIUM' THEN 1 ELSE 2 END, created_at DESC");
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < args.size(); i++) ps.setString(i + 1, args.get(i));
            List<Task> out = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(map(rs));
            }
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not load tasks: " + e.getMessage(), e);
        }
    }

    public int count(String where, String... args) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM tasks" + (where.isEmpty() ? "" : " WHERE " + where))) {
            for (int i = 0; i < args.length; i++) ps.setString(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not count tasks: " + e.getMessage(), e);
        }
    }

    /** Number of tasks completed on each of the last {@code days} days (oldest first). */
    public Map<LocalDate, Integer> completedPerDay(LocalDate today, int days) {
        Map<LocalDate, Integer> result = new LinkedHashMap<>();
        for (int i = days - 1; i >= 0; i--) result.put(today.minusDays(i), 0);
        String sql = "SELECT substr(completed_at,1,10) AS d, COUNT(*) FROM tasks WHERE status='COMPLETED' AND completed_at >= ? GROUP BY d";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, today.minusDays(days - 1).toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    LocalDate d = LocalDate.parse(rs.getString(1));
                    if (result.containsKey(d)) result.put(d, rs.getInt(2));
                }
            }
            return result;
        } catch (SQLException e) {
            throw new DatabaseException("Could not compute productivity data: " + e.getMessage(), e);
        }
    }

    private Task map(ResultSet rs) throws SQLException {
        String due = rs.getString("due_date");
        String done = rs.getString("completed_at");
        return new Task(rs.getLong("id"), rs.getString("title"), rs.getString("description"),
                Priority.valueOf(rs.getString("priority")), due == null ? null : LocalDate.parse(due),
                LocalDateTime.parse(rs.getString("created_at")), "COMPLETED".equals(rs.getString("status")),
                done == null ? null : LocalDateTime.parse(done));
    }
}
