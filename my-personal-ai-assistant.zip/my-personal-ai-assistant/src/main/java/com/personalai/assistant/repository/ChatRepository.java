package com.personalai.assistant.repository;

import com.personalai.assistant.db.Database;
import com.personalai.assistant.db.DatabaseException;
import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.model.Conversation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ChatRepository {
    private final Database db;

    public ChatRepository(Database db) { this.db = db; }

    public Conversation createConversation(String title) {
        LocalDateTime now = LocalDateTime.now().withNano(0);
        String sql = "INSERT INTO conversations(title, created_at, updated_at) VALUES (?,?,?)";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, now.toString());
            ps.setString(3, now.toString());
            ps.executeUpdate();
            return new Conversation(Database.lastInsertId(c), title, now, now);
        } catch (SQLException e) {
            throw new DatabaseException("Could not create the conversation: " + e.getMessage(), e);
        }
    }

    public void renameConversation(long id, String title) {
        exec("UPDATE conversations SET title=? WHERE id=?", title, id);
    }

    public ChatMessage addMessage(long conversationId, ChatMessage.Role role, String content) {
        LocalDateTime now = LocalDateTime.now().withNano(0);
        try (Connection c = db.connect()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO messages(conversation_id, role, content, created_at) VALUES (?,?,?,?)");
                 PreparedStatement up = c.prepareStatement("UPDATE conversations SET updated_at=? WHERE id=?")) {
                ps.setLong(1, conversationId);
                ps.setString(2, role.wire());
                ps.setString(3, content);
                ps.setString(4, now.toString());
                ps.executeUpdate();
                long id = Database.lastInsertId(c);
                up.setString(1, now.toString());
                up.setLong(2, conversationId);
                up.executeUpdate();
                c.commit();
                return new ChatMessage(id, conversationId, role, content, now);
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not save the message: " + e.getMessage(), e);
        }
    }

    public List<ChatMessage> messages(long conversationId) {
        List<ChatMessage> out = new ArrayList<>();
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM messages WHERE conversation_id=? ORDER BY id ASC")) {
            ps.setLong(1, conversationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new ChatMessage(rs.getLong("id"), rs.getLong("conversation_id"),
                            ChatMessage.Role.fromWire(rs.getString("role")), rs.getString("content"),
                            LocalDateTime.parse(rs.getString("created_at"))));
                }
            }
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not load messages: " + e.getMessage(), e);
        }
    }

    public List<Conversation> conversations(int limit) {
        List<Conversation> out = new ArrayList<>();
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM conversations ORDER BY updated_at DESC, id DESC LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(map(rs));
            }
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not load conversations: " + e.getMessage(), e);
        }
    }

    public Conversation findConversation(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM conversations WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not read the conversation: " + e.getMessage(), e);
        }
    }

    public void clearMessages(long conversationId) {
        exec("DELETE FROM messages WHERE conversation_id=?", conversationId);
    }

    public void deleteConversation(long id) {
        exec("DELETE FROM conversations WHERE id=?", id);
    }

    public void deleteAll() {
        try (Connection c = db.connect(); Statement st = c.createStatement()) {
            st.executeUpdate("DELETE FROM conversations"); // messages go too (ON DELETE CASCADE)
        } catch (SQLException e) {
            throw new DatabaseException("Could not clear chat history: " + e.getMessage(), e);
        }
    }

    public int countConversations() { return scalar("SELECT COUNT(*) FROM conversations"); }
    public int countMessages() { return scalar("SELECT COUNT(*) FROM messages"); }

    private int scalar(String sql) {
        try (Connection c = db.connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            throw new DatabaseException("Could not read chat statistics: " + e.getMessage(), e);
        }
    }

    private void exec(String sql, Object... args) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Database operation failed: " + e.getMessage(), e);
        }
    }

    private Conversation map(ResultSet rs) throws SQLException {
        return new Conversation(rs.getLong("id"), rs.getString("title"),
                LocalDateTime.parse(rs.getString("created_at")), LocalDateTime.parse(rs.getString("updated_at")));
    }
}
