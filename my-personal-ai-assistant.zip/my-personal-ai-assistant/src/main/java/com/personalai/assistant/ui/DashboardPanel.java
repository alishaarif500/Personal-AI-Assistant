package com.personalai.assistant.ui;

import com.personalai.assistant.model.Conversation;
import com.personalai.assistant.model.Note;
import com.personalai.assistant.model.Reminder;
import com.personalai.assistant.model.Task;
import com.personalai.assistant.service.DashboardService;
import com.personalai.assistant.util.Dates;
import com.personalai.assistant.util.Text;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** Home screen. Everything shown here is read from the SQLite database every time the page opens. */
public class DashboardPanel extends JPanel implements Page {
    private final DashboardService service;
    private final Navigator navigator;
    private final VerticalList content = new VerticalList();
    private final JLabel clock = Ui.label(" ", Theme.font(java.awt.Font.BOLD, 30f), Theme.TEXT);
    private final JLabel dateLabel = Ui.label(" ", Theme.base(), Theme.MUTED);
    private final JLabel greeting = Ui.label(" ", Theme.heading(), Theme.TEXT);
    private final Timer clockTimer = new Timer(1000, e -> updateClock());
    private final Timer refreshTimer = new Timer(30_000, e -> { if (isShowing()) refresh(); });

    public DashboardPanel(DashboardService service, Navigator navigator) {
        this.service = service;
        this.navigator = navigator;
        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 12, 24));
        add(Ui.scroll(content), BorderLayout.CENTER);
        clockTimer.start();
        refreshTimer.start();
        updateClock();
    }

    private void updateClock() {
        LocalDateTime now = LocalDateTime.now();
        clock.setText(Dates.TIME_SECONDS.format(now));
        dateLabel.setText(Dates.LONG_DATE.format(now));
        greeting.setText(Dates.greeting(now) + "!");
    }

    @Override public void onShow() { refresh(); }

    private void refresh() {
        content.removeAll();
        try {
            DashboardService.Snapshot s = service.load();
            content.add(header());
            content.add(Ui.vgap(20));
            content.add(stats(s));
            content.add(Ui.vgap(16));
            content.add(columns(s));
        } catch (RuntimeException e) {
            content.removeAll();
            content.add(header());
            content.add(Ui.vgap(16));
            content.add(Ui.banner("Could not load dashboard data: " + e.getMessage(), Theme.DANGER, Theme.DANGER_SOFT));
        }
        content.revalidate();
        content.repaint();
    }

    private JComponent header() {
        JPanel h = new JPanel(new BorderLayout());
        h.setOpaque(false);
        h.setAlignmentX(0f);
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        greeting.setAlignmentX(0f);
        dateLabel.setAlignmentX(0f);
        left.add(greeting);
        left.add(Ui.vgap(2));
        left.add(dateLabel);
        h.add(left, BorderLayout.WEST);
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setOpaque(false);
        right.add(clock);
        h.add(right, BorderLayout.EAST);
        h.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 70));
        return h;
    }

    private JComponent stats(DashboardService.Snapshot s) {
        JPanel row = new JPanel(new GridLayout(1, 4, 16, 0));
        row.setOpaque(false);
        row.setAlignmentX(0f);
        row.add(statCard(Icons.Type.CALENDAR, String.valueOf(s.dueToday()), "Due today", Theme.ACCENT, Theme.ACCENT_SOFT));
        row.add(statCard(Icons.Type.CLOCK, String.valueOf(s.pendingTasks()), s.overdue() > 0 ? "Pending · " + s.overdue() + " overdue" : "Pending tasks", Theme.WARNING, Theme.WARNING_SOFT));
        row.add(statCard(Icons.Type.CHECK, String.valueOf(s.completedTasks()), "Completed tasks", Theme.SUCCESS, Theme.SUCCESS_SOFT));
        row.add(statCard(Icons.Type.BELL, String.valueOf(s.upcomingReminders()), "Upcoming reminders", Theme.ACCENT, Theme.ACCENT_SOFT));
        row.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 100));
        return row;
    }

    private JComponent statCard(Icons.Type icon, String value, String label, Color fg, Color bg) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(14, 0));
        card.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        RoundedPanel badge = new RoundedPanel(new BorderLayout(), bg, null, 14);
        JLabel ic = new JLabel(Icons.of(icon, 24, fg));
        ic.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        badge.add(ic);
        JPanel badgeWrap = new JPanel(new BorderLayout());
        badgeWrap.setOpaque(false);
        badgeWrap.add(badge, BorderLayout.NORTH);
        card.add(badgeWrap, BorderLayout.WEST);
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.add(Ui.label(value, Theme.stat(), Theme.TEXT));
        text.add(Ui.label(label, Theme.small(), Theme.MUTED));
        card.add(text, BorderLayout.CENTER);
        return card;
    }

    private JComponent columns(DashboardService.Snapshot s) {
        JPanel grid = new JPanel(new GridBagLayout());
        grid.setOpaque(false);
        grid.setAlignmentX(0f);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0.5;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTH;

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.add(todayCard(s));
        left.add(Ui.vgap(16));
        left.add(productivityCard(s));

        JPanel right = new JPanel();
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.add(remindersCard(s));
        right.add(Ui.vgap(16));
        right.add(notesCard(s));
        right.add(Ui.vgap(16));
        right.add(chatsCard(s));

        c.gridx = 0; c.insets = new Insets(0, 0, 0, 8);
        grid.add(left, c);
        c.gridx = 1; c.insets = new Insets(0, 8, 0, 0);
        grid.add(right, c);
        return grid;
    }

    // ---- cards

    private RoundedPanel section(String title, String target, JComponent body) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 10));
        card.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        card.setAlignmentX(0f);
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.add(Ui.label(title, Theme.subheading(), Theme.TEXT), BorderLayout.WEST);
        if (target != null) {
            ModernButton more = new ModernButton("View all", ModernButton.Kind.GHOST);
            more.setPreferredSize(new java.awt.Dimension(84, 30));
            more.addActionListener(e -> navigator.navigate(target));
            head.add(more, BorderLayout.EAST);
        }
        card.add(head, BorderLayout.NORTH);
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel listBox() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }

    private JComponent muted(String text) {
        JLabel l = Ui.label(text, Theme.base(), Theme.MUTED);
        l.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        l.setAlignmentX(0f);
        return l;
    }

    private JComponent line(Icons.Type icon, Color iconColor, String title, String right, boolean strike) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        row.setAlignmentX(0f);
        row.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        row.add(new JLabel(Icons.of(icon, 18, iconColor)), BorderLayout.WEST);
        String t = Ui.escapeHtml(Text.truncate(title, 46));
        JLabel l = new JLabel(strike ? "<html><s>" + t + "</s></html>" : t);
        l.setFont(Theme.base());
        l.setForeground(strike ? Theme.MUTED : Theme.TEXT);
        row.add(l, BorderLayout.CENTER);
        if (right != null) row.add(Ui.label(right, Theme.small(), Theme.MUTED), BorderLayout.EAST);
        row.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 40));
        return row;
    }

    private JComponent todayCard(DashboardService.Snapshot s) {
        JPanel body = listBox();
        if (s.todayTasks().isEmpty()) body.add(muted("Nothing is due today."));
        for (Task t : s.todayTasks()) {
            body.add(line(t.completed() ? Icons.Type.CHECK : Icons.Type.TASKS, t.completed() ? Theme.SUCCESS : Theme.ACCENT,
                    t.title(), t.priority().label(), t.completed()));
        }
        return section("Today's tasks", Navigator.TASKS, body);
    }

    private JComponent productivityCard(DashboardService.Snapshot s) {
        JPanel body = listBox();
        JLabel summary = Ui.label(s.totalTasks() == 0 ? "No tasks yet — add some to see your progress."
                : s.completionPercent() + "% completed  (" + s.completedTasks() + " of " + s.totalTasks() + " tasks)", Theme.base(), Theme.TEXT);
        summary.setAlignmentX(0f);
        body.add(summary);
        body.add(Ui.vgap(8));
        ProgressBar bar = new ProgressBar(s.completionPercent());
        bar.setAlignmentX(0f);
        body.add(bar);
        body.add(Ui.vgap(16));
        JLabel cap = Ui.label("Tasks completed in the last 7 days", Theme.smallBold(), Theme.MUTED);
        cap.setAlignmentX(0f);
        body.add(cap);
        body.add(Ui.vgap(6));
        MiniBarChart chart = new MiniBarChart(s.completedLast7Days());
        chart.setAlignmentX(0f);
        body.add(chart);
        return section("Productivity overview", null, body);
    }

    private JComponent remindersCard(DashboardService.Snapshot s) {
        JPanel body = listBox();
        LocalDate today = LocalDate.now();
        if (s.reminders().isEmpty()) body.add(muted("No upcoming reminders."));
        for (Reminder r : s.reminders()) body.add(line(Icons.Type.BELL, Theme.ACCENT, r.title(), Dates.friendly(r.remindAt(), today), false));
        return section("Upcoming reminders", Navigator.REMINDERS, body);
    }

    private JComponent notesCard(DashboardService.Snapshot s) {
        JPanel body = listBox();
        if (s.recentNotes().isEmpty()) body.add(muted("No notes yet."));
        for (Note n : s.recentNotes()) body.add(line(Icons.Type.NOTES, Theme.ACCENT, n.title(), Dates.date(n.updatedAt().toLocalDate()), false));
        return section("Recent notes", Navigator.NOTES, body);
    }

    private JComponent chatsCard(DashboardService.Snapshot s) {
        JPanel body = listBox();
        if (s.recentChats().isEmpty()) body.add(muted("No conversations yet."));
        for (Conversation c : s.recentChats()) body.add(line(Icons.Type.CHAT, Theme.ACCENT, c.title(), Dates.date(c.updatedAt().toLocalDate()), false));
        return section("Recent AI conversations", Navigator.CHAT, body);
    }
}
