package com.personalai.assistant.ui;

import com.personalai.assistant.ai.AiException;
import com.personalai.assistant.ai.AiNotConfiguredException;
import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.model.Conversation;
import com.personalai.assistant.service.ChatService;
import com.personalai.assistant.util.Dates;
import com.personalai.assistant.util.Text;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.text.DefaultEditorKit;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ExecutionException;

/** AI chat: conversation list, message bubbles, input box, loading indicator and error handling. */
public class ChatPanel extends JPanel implements Page {
    private final ChatService chat;
    private final Navigator navigator;

    private final DefaultListModel<Conversation> convModel = new DefaultListModel<>();
    private final JList<Conversation> convList = new JList<>(convModel);
    private final VerticalList messages = new VerticalList();
    private final JScrollPane messageScroll = Ui.scroll(messages);
    private final JTextArea input = new HintTextArea(2, 20, "Type a message… (Enter to send, Shift+Enter for a new line)");
    private final ModernButton sendButton = new ModernButton("Send", ModernButton.Kind.PRIMARY).withIcon(Icons.Type.SEND);
    private final JLabel chatTitle = Ui.label("New conversation", Theme.subheading(), Theme.TEXT);
    private final JPanel bannerHolder = new JPanel(new BorderLayout());
    private final ModernButton clearButton = new ModernButton("Clear", ModernButton.Kind.SECONDARY);
    private final ModernButton deleteButton = new ModernButton("Delete", ModernButton.Kind.DANGER);

    private long currentId;          // 0 = draft conversation, not stored yet
    private long pendingId;          // conversation the AI is currently answering
    private boolean busy;
    private boolean loadingList;
    private TypingIndicator typing;
    private JComponent typingRow;

    public ChatPanel(ChatService chat, Navigator navigator) {
        this.chat = chat;
        this.navigator = navigator;
        setLayout(new BorderLayout(0, 16));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 24, 32));

        ModernButton newChat = new ModernButton("New conversation", ModernButton.Kind.PRIMARY).withIcon(Icons.Type.PLUS);
        newChat.addActionListener(e -> startNewConversation());
        add(Ui.pageHeader("AI Chat", "Ask questions, brainstorm and draft text", newChat), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(16, 0));
        body.setOpaque(false);
        body.add(buildConversationCard(), BorderLayout.WEST);
        body.add(buildChatCard(), BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);

        messageScroll.getViewport().addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) { messages.revalidate(); }
        });
        renderMessages(List.of());
    }

    // ------------------------------------------------------------------ layout

    private JComponent buildConversationCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 8));
        card.setBorder(BorderFactory.createEmptyBorder(14, 10, 10, 10));
        card.setPreferredSize(new Dimension(270, 100));
        JLabel head = Ui.label("HISTORY", Theme.smallBold(), Theme.MUTED);
        head.setBorder(BorderFactory.createEmptyBorder(0, 6, 6, 0));
        card.add(head, BorderLayout.NORTH);
        convList.setOpaque(false);
        convList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        convList.setCellRenderer(new ConversationRenderer());
        convList.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || loadingList) return;
            Conversation c = convList.getSelectedValue();
            if (c != null && c.id() != currentId) loadConversation(c.id());
        });
        card.add(Ui.scroll(convList), BorderLayout.CENTER);
        return card;
    }

    private JComponent buildChatCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 0));

        JPanel top = new JPanel(new BorderLayout(0, 8));
        top.setOpaque(false);
        top.setBorder(BorderFactory.createEmptyBorder(14, 18, 10, 14));
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.add(chatTitle, BorderLayout.WEST);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        clearButton.addActionListener(e -> clearConversation());
        deleteButton.addActionListener(e -> deleteConversation());
        actions.add(clearButton);
        actions.add(deleteButton);
        bar.add(actions, BorderLayout.EAST);
        top.add(bar, BorderLayout.NORTH);
        bannerHolder.setOpaque(false);
        top.add(bannerHolder, BorderLayout.SOUTH);
        card.add(top, BorderLayout.NORTH);

        messages.setBorder(BorderFactory.createEmptyBorder(4, 0, 8, 0));
        card.add(messageScroll, BorderLayout.CENTER);

        JPanel inputRow = new JPanel(new BorderLayout(10, 0));
        inputRow.setOpaque(false);
        inputRow.setBorder(BorderFactory.createEmptyBorder(8, 16, 16, 16));
        input.setLineWrap(true);
        input.setWrapStyleWord(true);
        input.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "send-message");
        input.getInputMap().put(KeyStroke.getKeyStroke("shift ENTER"), DefaultEditorKit.insertBreakAction);
        input.getActionMap().put("send-message", new javax.swing.AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { send(); }
        });
        RoundedPanel inputBox = Ui.textAreaBox(input, 62);
        inputBox.setToolTipText("Press Enter to send, Shift+Enter for a new line");
        inputRow.add(inputBox, BorderLayout.CENTER);
        JPanel sendWrap = new JPanel(new BorderLayout());
        sendWrap.setOpaque(false);
        sendButton.addActionListener(e -> send());
        sendButton.setPreferredSize(new Dimension(110, 42));
        sendWrap.add(sendButton, BorderLayout.SOUTH);
        inputRow.add(sendWrap, BorderLayout.EAST);
        card.add(inputRow, BorderLayout.SOUTH);
        return card;
    }

    // ------------------------------------------------------------------ data

    @Override public void onShow() {
        updateBanner();
        refreshConversationList();
        if (currentId != 0 && !busy) {
            try {
                renderMessages(chat.messages(currentId));
            } catch (RuntimeException ignored) { /* keep what is shown */ }
        }
        input.requestFocusInWindow();
    }

    private void updateBanner() {
        bannerHolder.removeAll();
        if (!chat.isAiConfigured()) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            JComponent b = Ui.banner("AI is not configured yet, so the assistant cannot answer. Add your API key in Settings (everything else keeps working).",
                    Theme.WARNING, Theme.WARNING_SOFT);
            row.add(b, BorderLayout.CENTER);
            ModernButton open = new ModernButton("Open Settings", ModernButton.Kind.SECONDARY);
            open.addActionListener(e -> navigator.navigate(Navigator.SETTINGS));
            JPanel east = new JPanel(new BorderLayout());
            east.setOpaque(false);
            east.add(open, BorderLayout.CENTER);
            row.add(east, BorderLayout.EAST);
            bannerHolder.add(row);
        }
        bannerHolder.revalidate();
        bannerHolder.repaint();
    }

    private void refreshConversationList() {
        try {
            List<Conversation> all = chat.conversations();
            loadingList = true;
            convModel.clear();
            all.forEach(convModel::addElement);
            for (int i = 0; i < convModel.size(); i++) {
                if (convModel.get(i).id() == currentId) { convList.setSelectedIndex(i); break; }
            }
            if (currentId == 0) convList.clearSelection();
            loadingList = false;
        } catch (RuntimeException e) {
            loadingList = false;
            showErrorRow("Could not load the conversation list: " + e.getMessage(), null);
        }
    }

    private void loadConversation(long id) {
        try {
            currentId = id;
            renderMessages(chat.messages(id));
        } catch (RuntimeException e) {
            showErrorRow("Could not load this conversation: " + e.getMessage(), null);
        }
    }

    private void startNewConversation() {
        currentId = 0;
        loadingList = true;
        convList.clearSelection();
        loadingList = false;
        renderMessages(List.of());
        input.requestFocusInWindow();
    }

    private void clearConversation() {
        if (currentId == 0) return;
        if (busy && pendingId == currentId) { Ui.message(this, "Please wait", "The assistant is still answering in this conversation.", false); return; }
        if (!Ui.confirm(this, "Clear conversation?", "All messages in this conversation will be deleted. The conversation itself stays in your history.", "Clear messages", true)) return;
        try {
            chat.clearConversation(currentId);
            renderMessages(List.of());
            refreshConversationList();
        } catch (RuntimeException e) {
            Ui.message(this, "Could not clear conversation", e.getMessage(), true);
        }
    }

    private void deleteConversation() {
        if (currentId == 0) return;
        if (busy && pendingId == currentId) { Ui.message(this, "Please wait", "The assistant is still answering in this conversation.", false); return; }
        if (!Ui.confirm(this, "Delete conversation?", "This conversation and all its messages will be permanently deleted.", "Delete", true)) return;
        try {
            chat.deleteConversation(currentId);
            currentId = 0;
            renderMessages(List.of());
            refreshConversationList();
        } catch (RuntimeException e) {
            Ui.message(this, "Could not delete conversation", e.getMessage(), true);
        }
    }

    // ------------------------------------------------------------------ sending

    private void send() {
        if (busy) return;
        String text = input.getText();
        if (Text.trimToNull(text) == null) return;
        if (text.strip().length() > ChatService.MAX_MESSAGE) {
            showErrorRow("That message is too long (maximum " + ChatService.MAX_MESSAGE + " characters).", null);
            return;
        }
        if (!chat.isAiConfigured()) {
            updateBanner();
            showErrorRow(new AiNotConfiguredException().getMessage(), null);
            return; // the text stays in the input box so nothing is lost
        }
        try {
            if (currentId == 0) currentId = chat.newConversation().id();
            chat.saveUserMessage(currentId, text);
            input.setText("");
            renderMessages(chat.messages(currentId));
            refreshConversationList();
        } catch (RuntimeException e) {
            showErrorRow("Could not save your message: " + e.getMessage(), null);
            return;
        }
        askAi();
    }

    private void askAi() {
        final long convId = currentId;
        busy = true;
        pendingId = convId;
        sendButton.setEnabled(false);
        showTyping();
        new SwingWorker<ChatMessage, Void>() {
            @Override protected ChatMessage doInBackground() throws Exception { return chat.requestReply(convId); }

            @Override protected void done() {
                busy = false;
                sendButton.setEnabled(true);
                hideTyping();
                try {
                    ChatMessage reply = get();
                    if (currentId == convId) renderMessages(chat.messages(convId));
                } catch (ExecutionException e) {
                    Throwable c = e.getCause();
                    String msg = c instanceof AiException ? c.getMessage() : "Unexpected error: " + (c == null ? e.getMessage() : c.getMessage());
                    if (currentId == convId) showErrorRow(msg, () -> askAi());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                refreshConversationList();
                input.requestFocusInWindow();
            }
        }.execute();
    }

    // ------------------------------------------------------------------ rendering

    private void renderMessages(List<ChatMessage> list) {
        hideTyping();
        messages.removeAll();
        Conversation c = null;
        try { if (currentId != 0) c = chatConversation(currentId); } catch (RuntimeException ignored) { /* title only */ }
        chatTitle.setText(c == null ? "New conversation" : Text.truncate(c.title(), 60));
        boolean exists = currentId != 0;
        clearButton.setEnabled(exists);
        deleteButton.setEnabled(exists);
        if (list.isEmpty()) {
            messages.add(Ui.emptyState(Icons.Type.CHAT, "How can I help today?",
                    chat.isAiConfigured() ? "Type a message below and press Enter." : "Configure an AI provider in Settings to start chatting."));
        }
        for (ChatMessage m : list) messages.add(bubbleRow(m.role() == ChatMessage.Role.USER, m.content(), m.createdAt(), false, null));
        if (busy && pendingId == currentId) showTyping();
        messages.revalidate();
        messages.repaint();
        scrollToBottom();
    }

    private Conversation chatConversation(long id) {
        for (int i = 0; i < convModel.size(); i++) if (convModel.get(i).id() == id) return convModel.get(i);
        for (Conversation c : chat.conversations()) if (c.id() == id) return c;
        return null;
    }

    private void showErrorRow(String text, Runnable retry) {
        hideTyping();
        messages.add(bubbleRow(false, text, LocalDateTime.now(), true, retry));
        messages.revalidate();
        messages.repaint();
        scrollToBottom();
    }

    private void showTyping() {
        hideTyping();
        typing = new TypingIndicator();
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setBorder(BorderFactory.createEmptyBorder(4, 18, 4, 18));
        row.add(typing, BorderLayout.WEST);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));
        typingRow = row;
        messages.add(row);
        messages.revalidate();
        scrollToBottom();
    }

    private void hideTyping() {
        if (typing != null) typing.stop();
        if (typingRow != null) {
            messages.remove(typingRow);
            messages.revalidate();
            messages.repaint();
        }
        typing = null;
        typingRow = null;
    }

    private JComponent bubbleRow(boolean user, String text, LocalDateTime time, boolean error, Runnable retry) {
        Color fill = error ? Theme.DANGER_SOFT : user ? Theme.USER_BUBBLE : Theme.ASSISTANT_BUBBLE;
        Color line = error ? null : user ? null : Theme.BORDER;
        Color fg = error ? Theme.DANGER : user ? Color.WHITE : Theme.ASSISTANT_TEXT;
        ChatBubble bubble = new ChatBubble(error ? "⚠ " + text : text, fill, line, fg,
                () -> {
                    int w = messageScroll.getViewport().getWidth();
                    return w <= 0 ? 520 : (int) (w * 0.74);
                });
        JPanel column = new JPanel();
        column.setOpaque(false);
        column.setLayout(new BoxLayout(column, BoxLayout.Y_AXIS));
        float align = user ? Component.RIGHT_ALIGNMENT : Component.LEFT_ALIGNMENT;
        bubble.setAlignmentX(align);
        column.add(bubble);
        JLabel stamp = Ui.label(error ? "Not saved" : (user ? "You" : "Assistant") + " · " + Dates.dateTime(time), Theme.small(), Theme.MUTED);
        stamp.setAlignmentX(align);
        stamp.setBorder(BorderFactory.createEmptyBorder(3, 4, 0, 4));
        column.add(stamp);
        if (retry != null) {
            ModernButton b = new ModernButton("Try again", ModernButton.Kind.SECONDARY);
            b.setAlignmentX(align);
            column.add(Ui.vgap(6));
            column.add(b);
            JPanel[] holder = new JPanel[1];
            b.addActionListener(e -> {
                messages.remove(holder[0]);
                messages.revalidate();
                retry.run();
            });
            JPanel row = rowWrap(column, user);
            holder[0] = row;
            return row;
        }
        return rowWrap(column, user);
    }

    private JPanel rowWrap(JComponent column, boolean user) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setBorder(BorderFactory.createEmptyBorder(5, 18, 5, 18));
        row.add(column, user ? BorderLayout.EAST : BorderLayout.WEST);
        return new JPanel(new BorderLayout()) {
            { setOpaque(false); setAlignmentX(Component.LEFT_ALIGNMENT); add(row); }
            @Override public Dimension getMaximumSize() { return new Dimension(Integer.MAX_VALUE, getPreferredSize().height); }
        };
    }

    private void scrollToBottom() {
        SwingUtilities.invokeLater(() -> SwingUtilities.invokeLater(() -> {
            JScrollBar bar = messageScroll.getVerticalScrollBar();
            bar.setValue(bar.getMaximum());
        }));
    }

    // ------------------------------------------------------------------ list renderer

    private static final class ConversationRenderer extends RoundedPanel implements ListCellRenderer<Conversation> {
        private final JLabel title = new JLabel();
        private final JLabel time = new JLabel();

        ConversationRenderer() {
            super(new BorderLayout(), null, null, 12);
            JPanel inner = new JPanel();
            inner.setOpaque(false);
            inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
            title.setFont(Theme.bold());
            time.setFont(Theme.small());
            inner.add(title);
            inner.add(Ui.vgap(2));
            inner.add(time);
            add(inner);
            setBorder(BorderFactory.createEmptyBorder(9, 12, 9, 12));
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Conversation> list, Conversation c, int index, boolean selected, boolean focus) {
            title.setText(Text.truncate(c.title(), 26));
            time.setText(Dates.dateTime(c.updatedAt()));
            setFill(selected ? Theme.ACCENT_SOFT : null);
            title.setForeground(Theme.TEXT);
            time.setForeground(Theme.MUTED);
            return this;
        }
    }
}
