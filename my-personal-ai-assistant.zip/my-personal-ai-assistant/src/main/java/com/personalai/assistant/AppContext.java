package com.personalai.assistant;

import com.personalai.assistant.config.AppConfig;
import com.personalai.assistant.db.Database;
import com.personalai.assistant.repository.ChatRepository;
import com.personalai.assistant.repository.NoteRepository;
import com.personalai.assistant.repository.ReminderRepository;
import com.personalai.assistant.repository.SettingsRepository;
import com.personalai.assistant.repository.TaskRepository;
import com.personalai.assistant.service.ChatService;
import com.personalai.assistant.service.DashboardService;
import com.personalai.assistant.service.NoteService;
import com.personalai.assistant.service.ReminderService;
import com.personalai.assistant.service.TaskService;

/** Wires together configuration, database, repositories and services (simple manual dependency injection). */
public final class AppContext {
    public final AppConfig config;
    public final Database database;
    public final TaskRepository taskRepo;
    public final NoteRepository noteRepo;
    public final ReminderRepository reminderRepo;
    public final ChatRepository chatRepo;
    public final SettingsRepository settings;
    public final TaskService tasks;
    public final NoteService notes;
    public final ReminderService reminders;
    public final ChatService chat;
    public final DashboardService dashboard;

    public AppContext(AppConfig config) {
        this.config = config;
        this.database = new Database(config.databaseFile());
        this.database.initialize();
        this.taskRepo = new TaskRepository(database);
        this.noteRepo = new NoteRepository(database);
        this.reminderRepo = new ReminderRepository(database);
        this.chatRepo = new ChatRepository(database);
        this.settings = new SettingsRepository(database);
        this.tasks = new TaskService(taskRepo);
        this.notes = new NoteService(noteRepo);
        this.reminders = new ReminderService(reminderRepo);
        this.chat = new ChatService(chatRepo, config);
        this.dashboard = new DashboardService(taskRepo, reminderRepo, noteRepo, chatRepo);
    }
}
