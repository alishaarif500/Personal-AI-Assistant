package com.personalai.assistant.ui;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.text.JTextComponent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

/** Factory methods for consistently styled widgets and dialogs. */
public final class Ui {
    private Ui() {}

    public static JLabel label(String text, Font font, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    public static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
    }

    public static Component vgap(int h) { return Box.createRigidArea(new Dimension(0, h)); }
    public static Component hgap(int w) { return Box.createRigidArea(new Dimension(w, 0)); }

    private static void styleText(JTextComponent c) {
        c.setOpaque(false);
        c.setFont(Theme.base());
        c.setForeground(Theme.TEXT);
        c.setCaretColor(Theme.TEXT);
        c.setSelectionColor(Theme.ACCENT);
        c.setSelectedTextColor(Color.WHITE);
        c.setBorder(BorderFactory.createEmptyBorder(9, 12, 9, 12));
    }

    private static void highlightOnFocus(JTextComponent c, RoundedPanel box) {
        c.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { box.setLine(Theme.ACCENT); }
            @Override public void focusLost(FocusEvent e) { box.setLine(Theme.BORDER); }
        });
    }

    /** A text field wrapped in a rounded box that highlights when focused. */
    public static RoundedPanel inputBox(JTextComponent c) {
        styleText(c);
        RoundedPanel box = new RoundedPanel(new BorderLayout(), Theme.INPUT_BG, Theme.BORDER, 12);
        box.add(c, BorderLayout.CENTER);
        highlightOnFocus(c, box);
        return box;
    }

    /** A multi-line text area in a scroll pane inside a rounded box. */
    public static RoundedPanel textAreaBox(JTextArea area, int preferredHeight) {
        styleText(area);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        JScrollPane sp = scroll(area);
        sp.setPreferredSize(new Dimension(100, preferredHeight));
        RoundedPanel box = new RoundedPanel(new BorderLayout(), Theme.INPUT_BG, Theme.BORDER, 12);
        box.add(sp, BorderLayout.CENTER);
        highlightOnFocus(area, box);
        return box;
    }

    public static JScrollPane scroll(Component c) {
        JScrollPane sp = new JScrollPane(c, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUI(new ThinScrollBarUI());
        sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.getVerticalScrollBar().setOpaque(false);
        return sp;
    }

    public static RoundedPanel card(int padding) {
        RoundedPanel p = new RoundedPanel(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(padding, padding, padding, padding));
        return p;
    }

    public static JComponent badge(String text, Color fg, Color bg) {
        RoundedPanel p = new RoundedPanel(new BorderLayout(), bg, null, 20);
        JLabel l = label(text, Theme.smallBold(), fg);
        l.setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
        p.add(l);
        return p;
    }

    public static JPanel pageHeader(String title, String subtitle, Component... actions) {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        JLabel t = label(title, Theme.heading(), Theme.TEXT);
        t.setAlignmentX(0f);
        text.add(t);
        if (subtitle != null) {
            text.add(vgap(2));
            JLabel s = label(subtitle, Theme.base(), Theme.MUTED);
            s.setAlignmentX(0f);
            text.add(s);
        }
        header.add(text, BorderLayout.WEST);
        if (actions.length > 0) {
            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            right.setOpaque(false);
            for (Component a : actions) right.add(a);
            header.add(right, BorderLayout.EAST);
        }
        return header;
    }

    public static JComponent emptyState(Icons.Type icon, String title, String subtitle) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(36, 20, 36, 20));
        JLabel ic = new JLabel(Icons.of(icon, 44, Theme.MUTED));
        ic.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel t = label(title, Theme.subheading(), Theme.TEXT);
        t.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel s = label(subtitle, Theme.base(), Theme.MUTED);
        s.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(ic);
        p.add(vgap(12));
        p.add(t);
        p.add(vgap(4));
        p.add(s);
        return p;
    }

    /** A coloured notice bar (info / warning / error). */
    public static JComponent banner(String text, Color fg, Color bg) {
        RoundedPanel p = new RoundedPanel(new BorderLayout(), bg, null, 12);
        JLabel l = new JLabel("<html><body style='width:100%'>" + escapeHtml(text) + "</body></html>");
        l.setFont(Theme.base());
        l.setForeground(fg);
        l.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        p.add(l);
        return p;
    }

    // ------------------------------------------------------------------ dialogs

    public static void message(Component parent, String title, String text, boolean error) {
        show(parent, title, text, error ? Theme.DANGER : Theme.ACCENT, "OK", null, false);
    }

    public static boolean confirm(Component parent, String title, String text, String okLabel, boolean danger) {
        return show(parent, title, text, danger ? Theme.DANGER : Theme.ACCENT, okLabel, "Cancel", danger);
    }

    private static boolean show(Component parent, String title, String text, Color accent, String okLabel, String cancelLabel, boolean danger) {
        Window owner = parent == null ? null : SwingUtilities.getWindowAncestor(parent);
        if (owner == null && parent instanceof Window w) owner = w;
        JDialog d = new JDialog(owner, title, Dialog.ModalityType.APPLICATION_MODAL);
        boolean[] result = {false};
        JPanel root = new JPanel(new BorderLayout(0, 16));
        root.setBackground(Theme.SURFACE);
        root.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER), BorderFactory.createEmptyBorder(22, 26, 18, 26)));
        root.add(label(title, Theme.subheading(), Theme.TEXT), BorderLayout.NORTH);
        JLabel body = new JLabel("<html><body style='width:340px'>" + escapeHtml(text) + "</body></html>");
        body.setFont(Theme.base());
        body.setForeground(Theme.MUTED);
        body.setVerticalAlignment(SwingConstants.TOP);
        root.add(body, BorderLayout.CENTER);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        if (cancelLabel != null) {
            ModernButton cancel = new ModernButton(cancelLabel, ModernButton.Kind.SECONDARY);
            cancel.addActionListener(e -> d.dispose());
            buttons.add(cancel);
        }
        ModernButton ok = new ModernButton(okLabel, danger ? ModernButton.Kind.DANGER : ModernButton.Kind.PRIMARY);
        ok.addActionListener(e -> { result[0] = true; d.dispose(); });
        buttons.add(ok);
        root.add(buttons, BorderLayout.SOUTH);
        d.setContentPane(root);
        d.getRootPane().setDefaultButton(null);
        d.setResizable(false);
        d.pack();
        d.setLocationRelativeTo(owner);
        d.getRootPane().registerKeyboardAction(e -> d.dispose(),
                javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
        d.setVisible(true);
        return result[0];
    }
}
