package com.personalai.assistant.ai;

import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.util.Json;

import java.util.List;
import java.util.Map;

/** Works with OpenAI and any service exposing the same /chat/completions API (OpenRouter, Groq, local servers...). */
public class OpenAiCompatibleProvider implements AiProvider {
    static final String SYSTEM_PROMPT = "You are a helpful, concise personal assistant inside a desktop productivity app.";

    private final String baseUrl;
    private final String apiKey;
    private final String model;

    public OpenAiCompatibleProvider(String baseUrl, String apiKey, String model) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey == null ? "" : apiKey;
        this.model = model;
    }

    @Override public String id() { return "openai"; }
    @Override public String displayName() { return "OpenAI-compatible (" + model + ")"; }
    @Override public boolean isConfigured() { return !apiKey.isBlank(); }

    String buildBody(List<ChatMessage> history) {
        StringBuilder sb = new StringBuilder("{\"model\":").append(Json.quote(model)).append(",\"messages\":[");
        sb.append("{\"role\":\"system\",\"content\":").append(Json.quote(SYSTEM_PROMPT)).append('}');
        for (ChatMessage m : history) {
            sb.append(",{\"role\":").append(Json.quote(m.role().wire()))
              .append(",\"content\":").append(Json.quote(m.content())).append('}');
        }
        return sb.append("]}").toString();
    }

    static String extractReply(Object parsed) throws AiException {
        Map<String, Object> root = Json.asObject(parsed);
        List<Object> choices = root == null ? null : Json.asArray(root.get("choices"));
        if (choices != null && !choices.isEmpty()) {
            Map<String, Object> first = Json.asObject(choices.get(0));
            Map<String, Object> msg = first == null ? null : Json.asObject(first.get("message"));
            if (msg != null && msg.get("content") instanceof String s && !s.isBlank()) return s.strip();
        }
        throw new AiException("The AI provider answered, but the reply was empty or in an unexpected format.");
    }

    @Override
    public String complete(List<ChatMessage> history) throws AiException {
        if (!isConfigured()) throw new AiNotConfiguredException();
        Object parsed = HttpSupport.postJson(baseUrl + "/chat/completions",
                Map.of("Authorization", "Bearer " + apiKey), buildBody(history));
        return extractReply(parsed);
    }
}
