package com.personalai.assistant;

import com.personalai.assistant.config.AppConfig;

import java.nio.file.Path;
import java.util.Map;

final class TestSupport {
    private TestSupport() {}

    /** A fresh context in a temp folder with no AI key (empty environment). */
    static AppContext newContext(Path dir) {
        return new AppContext(new AppConfig(dir, Map.of()));
    }
}
