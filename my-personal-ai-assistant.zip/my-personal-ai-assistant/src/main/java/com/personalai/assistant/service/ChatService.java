package com.personalai.assistant.service;

import com.personalai.assistant.ai.AiException;
import com.personalai.assistant.ai.AiProvider;
import com.personalai.assistant.ai.AiProviderFactory;
import com.personalai.assistant.config.AppConfig;
import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.model.Conversation;
import com.personalai.assistant.repository.ChatRepository;
import com.personalai.assistant.util.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Chat orchestration. The user's message is always saved. The assistant's message is saved only when the
 * provider actually returned an answer, so failed calls never leave fake replies in the history.
 */
public class ChatService {
    static final int CONTEXT_MESSAGES = 20;
    public static final int MAX_MESSAGE = 8000;

    private final ChatRepository repo;
    private final Supplier<AiProvider> providerSupplier;

    public ChatService(ChatRepository repo, AppConfig config) {
        this(repo, () -> AiProviderFactory.create(config));
    }

    public ChatService(ChatRepository repo, Supplier<AiProvider> providerSupplier) {
        this.repo = repo;
        this.providerSupplier = providerSupplier;
    }

    public AiProvider provider() { return providerSupplier.get(); }
    public boolean isAiConfigured() { return provider().isConfigured(); }

    public Conversation newConversation() { return repo.createConversation("New conversation"); }
    public List<Conversation> conversations() { return repo.conversations(200); }
    public List<Conversation> recentConversations(int limit) { return repo.conversations(limit); }
    public List<ChatMessage> messages(long conversationId) { return repo.messages(conversationId); }
    public void clearConversation(long id) { repo.clearMessages(id); repo.renameConversation(id, "New conversation"); }
    public void deleteConversation(long id) { repo.deleteConversation(id); }
    public void deleteAllHistory() { repo.deleteAll(); }

    /** Validates and stores the user message (call on the UI thread, it is quick). */
    public ChatMessage saveUserMessage(long conversationId, String text) {
        String t = Text.trimToNull(text);
        if (t == null) throw new ValidationException("Please type a message first.");
        if (t.length() > MAX_MESSAGE) throw new ValidationException("The message is too long (maximum " + MAX_MESSAGE + " characters).");
        if (repo.messages(conversationId).isEmpty()) repo.renameConversation(conversationId, Text.truncate(t, 40));
        return repo.addMessage(conversationId, ChatMessage.Role.USER, t);
    }

    /** Asks the AI for a reply (slow – call off the UI thread) and stores it. */
    public ChatMessage requestReply(long conversationId) throws AiException {
        AiProvider p = providerSupplier.get();
        List<ChatMessage> all = repo.messages(conversationId);
        List<ChatMessage> ctx = new ArrayList<>(all.subList(Math.max(0, all.size() - CONTEXT_MESSAGES), all.size()));
        while (!ctx.isEmpty() && ctx.get(0).role() != ChatMessage.Role.USER) ctx.remove(0);
        String reply = p.complete(ctx);
        return repo.addMessage(conversationId, ChatMessage.Role.ASSISTANT, reply);
    }
}
