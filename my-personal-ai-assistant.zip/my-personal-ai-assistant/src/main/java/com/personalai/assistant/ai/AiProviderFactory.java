package com.personalai.assistant.ai;

import com.personalai.assistant.config.AppConfig;

/** Builds the provider selected in the configuration. Add new providers here. */
public final class AiProviderFactory {
    private AiProviderFactory() {}

    public static AiProvider create(AppConfig cfg) {
        return switch (cfg.provider()) {
            case "anthropic" -> new AnthropicProvider(cfg.baseUrl(), cfg.apiKey(), cfg.model());
            default -> new OpenAiCompatibleProvider(cfg.baseUrl(), cfg.apiKey(), cfg.model());
        };
    }
}
