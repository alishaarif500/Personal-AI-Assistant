package com.personalai.assistant.model;

import java.time.LocalDateTime;

public record Note(long id, String title, String content, LocalDateTime createdAt, LocalDateTime updatedAt) {}
