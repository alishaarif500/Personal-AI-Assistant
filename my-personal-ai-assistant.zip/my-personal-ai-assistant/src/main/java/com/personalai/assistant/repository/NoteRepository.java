package com.personalai.assistant.repository;

import com.personalai.assistant.db.Database;
import com.personalai.assistant.db.DatabaseException;
import com.personalai.assistant.model.Note;
import com.personalai.assistant.util.Text;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NoteRepository {
    private final Database db;

    public NoteRepository(Database db) { this.db = db; }

    public Note insert(String title, String content) {
        LocalDateTime now = LocalDateTime.now().withNano(0);
        String sql = "INSERT INTO notes(title, content, created_at, updated_at) VALUES (?,?,?,?)";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, content);
            ps.setString(3, now.toString());
            ps.setString(4, now.toString());
            ps.executeUpdate();
            return new Note(Database.lastInsertId(c), title, content, now, now);
        } catch (SQLException e) {
            throw new DatabaseException("Could not save the note: " + e.getMessage(), e);
        }
    }

    public boolean update(long id, String title, String content) {
        String sql = "UPDATE notes SET title=?, content=?, updated_at=? WHERE id=?";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, content);
            ps.setString(3, LocalDateTime.now().withNano(0).toString());
            ps.setLong(4, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not update the note: " + e.getMessage(), e);
        }
    }

    public boolean delete(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM notes WHERE id=?")) {
            ps.setLong(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new DatabaseException("Could not delete the note: " + e.getMessage(), e);
        }
    }

    public Note findById(long id) {
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM notes WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Could not read the note: " + e.getMessage(), e);
        }
    }

    public List<Note> search(String query, int limit) {
        String q = Text.trimToNull(query);
        String sql = "SELECT * FROM notes" + (q == null ? "" : " WHERE title LIKE ? ESCAPE '\\' OR content LIKE ? ESCAPE '\\'")
                + " ORDER BY updated_at DESC, id DESC LIMIT ?";
        try (Connection c = db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            if (q != null) {
                String like = "%" + Text.likeEscape(q) + "%";
                ps.setString(i++, like);
                ps.setString(i++, like);
            }
            ps.setInt(i, limit);
            List<Note> out = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(map(rs));
            }
            return out;
        } catch (SQLException e) {
            throw new DatabaseException("Could not load notes: " + e.getMessage(), e);
        }
    }

    public int count() {
        try (Connection c = db.connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM notes")) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            throw new DatabaseException("Could not count notes: " + e.getMessage(), e);
        }
    }

    private Note map(ResultSet rs) throws SQLException {
        return new Note(rs.getLong("id"), rs.getString("title"), rs.getString("content"),
                LocalDateTime.parse(rs.getString("created_at")), LocalDateTime.parse(rs.getString("updated_at")));
    }
}
