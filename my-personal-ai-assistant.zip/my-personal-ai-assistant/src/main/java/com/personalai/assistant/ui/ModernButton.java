package com.personalai.assistant.ui;

import javax.swing.Icon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Flat, rounded button with hover and pressed states. */
public class ModernButton extends JButton {
    public enum Kind { PRIMARY, SECONDARY, DANGER, GHOST }

    private final Kind kind;
    private boolean hover;
    private Icons.Type iconType;

    public ModernButton(String text, Kind kind) {
        super(text);
        this.kind = kind;
        setFont(Theme.bold());
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
            @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
        });
    }

    public ModernButton withIcon(Icons.Type type) { this.iconType = type; revalidate(); repaint(); return this; }

    private Color foreground() {
        return switch (kind) {
            case PRIMARY -> Color.WHITE;
            case DANGER -> Theme.DANGER;
            case SECONDARY -> Theme.TEXT;
            case GHOST -> hover ? Theme.ACCENT : Theme.MUTED;
        };
    }

    private Color background() {
        boolean pressed = getModel().isArmed();
        return switch (kind) {
            case PRIMARY -> pressed ? Theme.ACCENT_HOVER.darker() : hover ? Theme.ACCENT_HOVER : Theme.ACCENT;
            case SECONDARY -> hover ? Theme.SURFACE_ALT : Theme.SURFACE;
            case DANGER -> hover ? Theme.DANGER_SOFT : Theme.SURFACE;
            case GHOST -> hover ? Theme.SURFACE_ALT : null;
        };
    }

    @Override public Dimension getPreferredSize() {
        FontMetrics fm = getFontMetrics(getFont());
        int w = fm.stringWidth(getText() == null ? "" : getText()) + 36 + (iconType != null ? 24 : 0);
        return new Dimension(w, 38);
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        if (!isEnabled()) g2.setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_OVER, 0.45f));
        Color bg = background();
        int w = getWidth(), h = getHeight();
        if (bg != null) {
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, w - 1, h - 1, 12, 12);
        }
        if (kind == Kind.SECONDARY || kind == Kind.DANGER) {
            g2.setColor(kind == Kind.DANGER ? Theme.DANGER : Theme.BORDER);
            g2.drawRoundRect(0, 0, w - 1, h - 1, 12, 12);
        }
        g2.setFont(getFont());
        FontMetrics fm = g2.getFontMetrics();
        String text = getText() == null ? "" : getText();
        int iconW = iconType != null ? 20 : 0;
        int gap = iconType != null && !text.isEmpty() ? 6 : 0;
        int total = iconW + gap + fm.stringWidth(text);
        int x = (w - total) / 2;
        g2.setColor(foreground());
        if (iconType != null) {
            Icons.paint((Graphics2D) g2.create(), iconType, x, (h - 18) / 2, 18, foreground());
            x += iconW + gap;
        }
        g2.drawString(text, x, (h - fm.getHeight()) / 2 + fm.getAscent());
        g2.dispose();
    }
}
