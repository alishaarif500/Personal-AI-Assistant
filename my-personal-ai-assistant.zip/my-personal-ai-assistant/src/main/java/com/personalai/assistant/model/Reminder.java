package com.personalai.assistant.model;

import java.time.LocalDateTime;

public record Reminder(long id, String title, String description, LocalDateTime remindAt,
                       boolean notified, LocalDateTime createdAt) {}
