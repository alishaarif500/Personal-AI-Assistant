# My Personal AI Assistant

A modern desktop productivity app for Windows (and macOS/Linux) built with **Java 17, Swing, SQLite and Maven**.
It combines an AI chat assistant with offline task, reminder and note tools, all stored locally on your computer.

![Dashboard](docs/screenshots/dashboard.png)

## Features

| Module | What it does |
|---|---|
| **Dashboard** | Greeting, live clock, today's tasks, pending/completed counts, upcoming reminders, recent notes, recent AI conversations, 7-day productivity chart. All numbers come from the SQLite database. |
| **AI Chat** | Message bubbles, Enter-to-send (Shift+Enter = new line), conversation history with timestamps, new / clear / delete conversation, animated loading indicator, clear error messages with a "Try again" button. |
| **Tasks** | Add, edit, delete, complete / reopen. Title, description, priority, due date, created date, status. Search plus filters: All, Pending, Completed, High priority, Today. |
| **Reminders** | Add, edit, delete. A background scheduler checks every 10 seconds and shows a pop-up notification. Each reminder fires exactly once, and reminders that came due while the app was closed are shown at the next start. |
| **Notes** | Add, edit, delete, search. Created and last-updated dates, unsaved-changes protection, Ctrl+S to save. |
| **Settings** | Light/dark theme, AI configuration status and instructions, database info, backup, clear chat history, delete completed tasks. |

**The AI is never faked.** Without an API key the chat tells you so and nothing is sent; every offline feature keeps working.

## Screenshots

| Chat | Tasks |
|---|---|
| ![Chat](docs/screenshots/chat.png) | ![Tasks](docs/screenshots/tasks.png) |
| **Notes** | **Reminders** |
| ![Notes](docs/screenshots/notes.png) | ![Reminders](docs/screenshots/reminders.png) |

Dark mode: ![Dark dashboard](docs/screenshots/dashboard-dark.png)

*(The screenshots use demo data. To retake them, run the app, resize the window to about 1260×800 and use your OS screenshot tool, then replace the files in `docs/screenshots/`.)*

## Technology stack

- Java 17 and Swing (custom-painted components, no look-and-feel library needed)
- SQLite through JDBC (`org.xerial:sqlite-jdbc`), prepared statements everywhere
- `java.net.http.HttpClient` for AI calls (OpenAI-compatible and Anthropic providers)
- Maven for building, JUnit 5 for tests

## Installation on Windows (step by step)

You need two free tools. Open **PowerShell** and run:

```powershell
winget install EclipseAdoptium.Temurin.17.JDK
winget install Apache.Maven
```

Close PowerShell and open it again (so the new tools are found), then check:

```powershell
java -version     # should say 17 or higher
mvn -version
```

> If `winget` is not available, download the JDK from <https://adoptium.net> (choose version 17, Windows x64 .msi, tick "Set JAVA_HOME") and Maven from <https://maven.apache.org/download.cgi> (unzip and add its `bin` folder to PATH).

## Run it (VS Code)

1. Extract the project ZIP.
2. In VS Code choose **File → Open Folder…** and pick the extracted `my-personal-ai-assistant` folder. (Optional: install the "Extension Pack for Java" when VS Code suggests it.)
3. Open a terminal with **Terminal → New Terminal** and run this one command:

```powershell
mvn -q compile exec:java
```

The first run downloads the dependencies automatically (needs internet, takes a minute). Then the application window opens.

Prefer double-clicking? Use `run.bat` in the project folder.

### Build a single runnable jar (optional)

```powershell
mvn clean package
java -jar target\my-personal-ai-assistant.jar
```

## Configure the AI (optional)

The chat needs an API key from an AI provider. Tasks, reminders and notes work without one.

**Option A, easiest (no restart needed):**
1. Open the app → **Settings** → **Create config file**. A template opens in the app's data folder.
2. Open `config.properties` in Notepad, replace `PASTE_YOUR_API_KEY_HERE` with your key, save.
3. Back in the app click **Reload configuration**. The status turns to "Configured".

**Option B, environment variables** (restart the app afterwards):

```powershell
setx AI_API_KEY "your-key-here"
```

| Setting | Config file key | Environment variable | Default |
|---|---|---|---|
| Provider | `ai.provider` | `AI_PROVIDER` | `openai` (or `anthropic`) |
| API key | `ai.api.key` | `AI_API_KEY` | none |
| Base URL | `ai.base.url` | `AI_BASE_URL` | provider default |
| Model | `ai.model` | `AI_MODEL` | `gpt-4o-mini` / `claude-sonnet-5-5` |

Environment variables win over the config file. See `config.properties.example`.
The key is stored only on your computer and is sent only to the provider you chose. It is never part of the source code, and `.gitignore` excludes `config.properties`.

To add another provider later: implement the small `AiProvider` interface (`ai` package) and register it in `AiProviderFactory`.

## Where is my data?

| | Location |
|---|---|
| Windows | `%APPDATA%\MyPersonalAIAssistant\` |
| macOS / Linux | `~/.my-personal-ai-assistant/` |

It contains `assistant.db` (the SQLite database, created automatically on first launch) and, if you made one, `config.properties`.
Tables: `tasks`, `notes`, `reminders`, `conversations`, `messages` (foreign key to conversations, cascade delete), `settings`.
Use **Settings → Back up database…** to copy it elsewhere. To start from scratch, close the app and delete the folder.

## Tests

```powershell
mvn test
```

35 JUnit 5 tests cover database creation, task / note / reminder CRUD and validation, the reminder scheduler (including "never notify twice" under concurrency), chat persistence, missing-API-key behaviour, provider request/response handling, configuration precedence and JSON parsing. Tests use temporary folders and never touch your real data. See [VERIFICATION.md](VERIFICATION.md) for what was actually run.

## Project structure

```
pom.xml                       Maven build (Java 17, sqlite-jdbc, JUnit 5, shade + exec plugins)
run.bat                       Windows double-click launcher
config.properties.example     AI configuration template
src/main/java/com/personalai/assistant/
  App.java                    Entry point, theme switching
  AppContext.java             Wires repositories and services together
  config/AppConfig.java       Data folder, env/file configuration
  db/                         Database (connections, schema), DatabaseException
  model/                      Task, Note, Reminder, Conversation, ChatMessage, enums
  repository/                 JDBC repositories (prepared statements only)
  service/                    Validation + business logic, reminder scheduler, chat orchestration
  ai/                         AiProvider interface, OpenAI-compatible and Anthropic providers
  util/                       JSON, date and text helpers
  ui/                         Main window, pages and custom Swing components
src/test/java/...             JUnit 5 tests
docs/screenshots/             Screenshots used in this README
```

## Troubleshooting

- **`mvn` is not recognised**: close and reopen PowerShell after installing, or check Maven's `bin` folder is on PATH.
- **`release version 17 not supported`**: your JDK is older than 17. Check `java -version` and `mvn -version` (it prints the JDK Maven uses; set `JAVA_HOME` to the JDK 17 folder).
- **The chat says "AI is not configured"**: see "Configure the AI" above, then click *Reload configuration*.
- **"The AI provider rejected your API key (401)"**: the key is wrong, expired, or belongs to a different provider than `ai.provider`.
- **No reminder pop-up**: reminders only fire while the application is running.

## License

MIT, see [LICENSE](LICENSE).
