package com.personalai.assistant.service;

import com.personalai.assistant.model.Note;
import com.personalai.assistant.repository.NoteRepository;
import com.personalai.assistant.util.Text;

import java.util.List;

public class NoteService {
    public static final int MAX_TITLE = 150;
    public static final int MAX_CONTENT = 100_000;

    private final NoteRepository repo;

    public NoteService(NoteRepository repo) { this.repo = repo; }

    public Note create(String title, String content) {
        return repo.insert(validateTitle(title), validateContent(content));
    }

    public void update(long id, String title, String content) {
        if (!repo.update(id, validateTitle(title), validateContent(content))) {
            throw new ValidationException("This note no longer exists. It may have been deleted.");
        }
    }

    public void delete(long id) {
        if (!repo.delete(id)) throw new ValidationException("This note no longer exists.");
    }

    public Note get(long id) { return repo.findById(id); }

    public List<Note> search(String query) { return repo.search(query, 1000); }

    public List<Note> recent(int limit) { return repo.search(null, limit); }

    private static String validateTitle(String title) {
        String t = Text.trimToNull(title);
        if (t == null) throw new ValidationException("Please enter a note title.");
        if (t.length() > MAX_TITLE) throw new ValidationException("The note title is too long (maximum " + MAX_TITLE + " characters).");
        return t;
    }

    private static String validateContent(String c) {
        String s = c == null ? "" : c;
        if (s.length() > MAX_CONTENT) throw new ValidationException("The note is too long (maximum " + MAX_CONTENT + " characters).");
        return s;
    }
}
