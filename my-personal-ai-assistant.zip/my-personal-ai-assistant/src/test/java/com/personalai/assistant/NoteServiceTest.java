package com.personalai.assistant;

import com.personalai.assistant.model.Note;
import com.personalai.assistant.service.NoteService;
import com.personalai.assistant.service.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class NoteServiceTest {
    NoteService notes;

    @BeforeEach
    void setUp(@TempDir Path dir) { notes = TestSupport.newContext(dir).notes; }

    @Test
    void createUpdateSearchDelete() {
        Note n = notes.create("Groceries", "milk, eggs\nbread");
        assertEquals("milk, eggs\nbread", notes.get(n.id()).content());

        notes.update(n.id(), "Shopping", "milk");
        Note u = notes.get(n.id());
        assertEquals("Shopping", u.title());
        assertFalse(u.updatedAt().isBefore(u.createdAt()));

        notes.create("Ideas", "build an app");
        assertEquals(1, notes.search("app").size());
        assertEquals(1, notes.search("SHOPP").size());
        assertEquals(2, notes.search("").size());
        assertEquals(2, notes.recent(10).size());

        notes.delete(n.id());
        assertNull(notes.get(n.id()));
        assertThrows(ValidationException.class, () -> notes.delete(n.id()));
    }

    @Test
    void validation() {
        assertThrows(ValidationException.class, () -> notes.create("", "text"));
        assertThrows(ValidationException.class, () -> notes.update(999, "t", "c"));
    }
}
