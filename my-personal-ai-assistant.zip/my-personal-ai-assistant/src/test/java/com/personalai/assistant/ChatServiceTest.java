package com.personalai.assistant;

import com.personalai.assistant.ai.AiException;
import com.personalai.assistant.ai.AiNotConfiguredException;
import com.personalai.assistant.ai.AiProvider;
import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.model.Conversation;
import com.personalai.assistant.service.ChatService;
import com.personalai.assistant.service.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

class ChatServiceTest {
    static class FakeProvider implements AiProvider {
        boolean configured = true;
        String reply = "Hello from the fake provider";
        AiException failure;
        List<ChatMessage> lastHistory;
        @Override public String id() { return "fake"; }
        @Override public String displayName() { return "Fake"; }
        @Override public boolean isConfigured() { return configured; }
        @Override public String complete(List<ChatMessage> history) throws AiException {
            if (!configured) throw new AiNotConfiguredException();
            lastHistory = history;
            if (failure != null) throw failure;
            return reply;
        }
    }

    FakeProvider provider = new FakeProvider();
    AppContext ctx;
    ChatService chat;

    @BeforeEach
    void setUp(@TempDir Path dir) {
        ctx = TestSupport.newContext(dir);
        chat = new ChatService(ctx.chatRepo, () -> provider);
    }

    @Test
    void conversationRoundTripIsPersisted() throws Exception {
        Conversation c = chat.newConversation();
        chat.saveUserMessage(c.id(), "What is 2+2?");
        ChatMessage reply = chat.requestReply(c.id());
        assertEquals(ChatMessage.Role.ASSISTANT, reply.role());

        List<ChatMessage> msgs = chat.messages(c.id());
        assertEquals(2, msgs.size());
        assertEquals("What is 2+2?", msgs.get(0).content());
        assertEquals("Hello from the fake provider", msgs.get(1).content());
        assertEquals("What is 2+2?", chat.conversations().get(0).title(), "title comes from the first message");
        assertEquals(ChatMessage.Role.USER, provider.lastHistory.get(provider.lastHistory.size() - 1).role());
    }

    @Test
    void failedCallStoresNoFakeAssistantMessage() throws Exception {
        Conversation c = chat.newConversation();
        chat.saveUserMessage(c.id(), "hi");
        provider.failure = new AiException("network down");
        AiException e = assertThrows(AiException.class, () -> chat.requestReply(c.id()));
        assertEquals("network down", e.getMessage());
        assertEquals(1, chat.messages(c.id()).size());
    }

    @Test
    void missingApiKeyIsReportedNotFaked() {
        provider.configured = false;
        assertFalse(chat.isAiConfigured());
        Conversation c = chat.newConversation();
        chat.saveUserMessage(c.id(), "hello");
        assertThrows(AiNotConfiguredException.class, () -> chat.requestReply(c.id()));
        assertEquals(1, chat.messages(c.id()).size());
    }

    @Test
    void clearAndDeleteAndValidation() {
        Conversation c = chat.newConversation();
        chat.saveUserMessage(c.id(), "one");
        chat.clearConversation(c.id());
        assertTrue(chat.messages(c.id()).isEmpty());
        assertEquals(1, chat.conversations().size());

        chat.saveUserMessage(c.id(), "two");
        chat.deleteConversation(c.id());
        assertTrue(chat.conversations().isEmpty());
        assertEquals(0, ctx.chatRepo.countMessages(), "messages are removed with their conversation (cascade)");

        Conversation d = chat.newConversation();
        assertThrows(ValidationException.class, () -> chat.saveUserMessage(d.id(), "   "));
        assertThrows(ValidationException.class, () -> chat.saveUserMessage(d.id(), "x".repeat(ChatService.MAX_MESSAGE + 1)));
    }

    @Test
    void contextIsLimitedAndStartsWithUserMessage() throws Exception {
        Conversation c = chat.newConversation();
        AtomicReference<Integer> size = new AtomicReference<>();
        for (int i = 0; i < 15; i++) {
            chat.saveUserMessage(c.id(), "q" + i);
            chat.requestReply(c.id());
        }
        chat.saveUserMessage(c.id(), "last");
        chat.requestReply(c.id());
        size.set(provider.lastHistory.size());
        assertTrue(size.get() <= 20);
        assertEquals(ChatMessage.Role.USER, provider.lastHistory.get(0).role());
    }
}
