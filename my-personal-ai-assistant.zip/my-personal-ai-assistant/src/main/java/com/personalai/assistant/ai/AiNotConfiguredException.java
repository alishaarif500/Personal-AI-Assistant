package com.personalai.assistant.ai;

/** Thrown when no API key is available. No fake answer is ever produced in this case. */
public class AiNotConfiguredException extends AiException {
    public AiNotConfiguredException() {
        super("No AI provider is configured yet. Open Settings to see how to add your API key. "
                + "All other features (tasks, reminders, notes) work without it.");
    }
}
