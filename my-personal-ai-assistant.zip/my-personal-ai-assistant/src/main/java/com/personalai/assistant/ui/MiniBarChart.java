package com.personalai.assistant.ui;

import javax.swing.JComponent;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Map;

/** Tiny bar chart (one bar per day) for the dashboard. */
public class MiniBarChart extends JComponent {
    private final Map<LocalDate, Integer> data;

    public MiniBarChart(Map<LocalDate, Integer> data) {
        this.data = data;
        setPreferredSize(new Dimension(300, 120));
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        int n = data.size();
        if (n == 0) { g2.dispose(); return; }
        int max = Math.max(1, data.values().stream().mapToInt(Integer::intValue).max().orElse(1));
        int labelH = 20, topPad = 16;
        int chartH = getHeight() - labelH - topPad;
        int slot = getWidth() / n;
        int barW = Math.min(34, slot - 12);
        g2.setFont(Theme.small());
        FontMetrics fm = g2.getFontMetrics();
        int i = 0;
        LocalDate today = LocalDate.now();
        for (Map.Entry<LocalDate, Integer> e : data.entrySet()) {
            int v = e.getValue();
            int h = v == 0 ? 4 : Math.max(8, (int) Math.round((double) v / max * chartH));
            int x = i * slot + (slot - barW) / 2;
            int y = topPad + chartH - h;
            g2.setColor(v == 0 ? Theme.BORDER : e.getKey().equals(today) ? Theme.ACCENT : Theme.ACCENT_HOVER);
            g2.fillRoundRect(x, y, barW, h, 8, 8);
            if (v > 0) {
                g2.setColor(Theme.TEXT);
                String s = String.valueOf(v);
                g2.drawString(s, x + (barW - fm.stringWidth(s)) / 2, y - 4);
            }
            String day = e.getKey().getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            g2.setColor(e.getKey().equals(today) ? Theme.TEXT : Theme.MUTED);
            g2.drawString(day, i * slot + (slot - fm.stringWidth(day)) / 2, getHeight() - 5);
            i++;
        }
        g2.dispose();
    }
}
