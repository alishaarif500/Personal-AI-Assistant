package com.personalai.assistant.ai;

import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.util.Json;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ProviderTest {
    static ChatMessage msg(String text) {
        return new ChatMessage(1, 1, ChatMessage.Role.USER, text, LocalDateTime.now());
    }

    @Test
    void providersWithoutKeyRefuseToAnswer() {
        assertThrows(AiNotConfiguredException.class, () -> new OpenAiCompatibleProvider("http://x", "", "m").complete(List.of(msg("hi"))));
        assertThrows(AiNotConfiguredException.class, () -> new AnthropicProvider("http://x", "  ", "m").complete(List.of(msg("hi"))));
    }

    @Test
    void openAiRequestBodyIsValidJsonWithEscaping() {
        String body = new OpenAiCompatibleProvider("http://x", "k", "gpt").buildBody(List.of(msg("say \"hi\"\nnew line \\ tab\t")));
        Map<String, Object> root = Json.asObject(Json.parse(body));
        assertEquals("gpt", root.get("model"));
        List<Object> messages = Json.asArray(root.get("messages"));
        assertEquals(2, messages.size());
        assertEquals("say \"hi\"\nnew line \\ tab\t", Json.asObject(messages.get(1)).get("content"));
    }

    @Test
    void parsesOpenAiAndAnthropicReplies() throws Exception {
        String openai = "{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"Hi there\"}}]}";
        assertEquals("Hi there", OpenAiCompatibleProvider.extractReply(Json.parse(openai)));
        String anth = "{\"content\":[{\"type\":\"text\",\"text\":\"Hello \"},{\"type\":\"text\",\"text\":\"world\"}]}";
        assertEquals("Hello world", AnthropicProvider.extractReply(Json.parse(anth)));
    }

    @Test
    void unexpectedReplyShapeIsAnError() {
        assertThrows(AiException.class, () -> OpenAiCompatibleProvider.extractReply(Json.parse("{\"choices\":[]}")));
        assertThrows(AiException.class, () -> AnthropicProvider.extractReply(Json.parse("{\"content\":[]}")));
    }

    @Test
    void networkFailureBecomesFriendlyMessage() {
        // Port 1 on localhost: connection refused, no internet needed.
        OpenAiCompatibleProvider p = new OpenAiCompatibleProvider("http://127.0.0.1:1/v1", "key", "m");
        AiException e = assertThrows(AiException.class, () -> p.complete(List.of(msg("hi"))));
        assertFalse(e.getMessage().isBlank());
    }

    @Test
    void factoryPicksProvider() {
        var cfg = new com.personalai.assistant.config.AppConfig(java.nio.file.Path.of("nonexistent-dir-for-test"),
                Map.of("AI_PROVIDER", "anthropic", "AI_API_KEY", "k"));
        assertEquals("anthropic", AiProviderFactory.create(cfg).id());
    }
}
