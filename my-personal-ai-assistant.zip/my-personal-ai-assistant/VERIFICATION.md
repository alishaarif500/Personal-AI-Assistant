# Verification report

Date of verification: 10 November 2026. Environment: Ubuntu 24.04 sandbox, OpenJDK **17.0.20** (`javac 17.0.20.1`), virtual display (Xvfb) with the Openbox window manager.

## Please read first: what could NOT be verified

1. **Apache Maven could not be run.** The sandbox cannot reach Maven Central (network allow-list), so `mvn clean`, `mvn compile`, `mvn test` and `mvn package` were **never executed**. I replaced them with the closest equivalent steps below (plain `javac --release 17`, the JUnit 5 console launcher, and `jar`). The `pom.xml` is well-formed XML and uses standard, published plugin/dependency versions, but **it has not been executed by Maven**. If your first `mvn` run fails, please send me the error text.
2. **Not tested on Windows.** Everything ran on Linux. The code uses `%APPDATA%` on Windows and the sqlite-jdbc jar bundles Windows native libraries, but I have not seen it run on Windows 10/11. Fonts differ there (the app prefers Segoe UI).
3. **No real AI provider was called.** No API key was available. The HTTP client, request format, authentication header, error handling and conversation history were verified end to end against a **local mock server** that imitates the OpenAI chat-completions API (including a simulated HTTP 429). The Anthropic provider is covered by unit tests of request/response parsing only.
4. **Library versions differ slightly from the pom.** The tests ran against the Linux-packaged SQLite JDBC 3.44.1.0 and JUnit 5.10.1, whereas the pom pins sqlite-jdbc 3.46.1.0 and JUnit 5.10.2.
5. **A reminder that becomes due while the app is open** is covered by the scheduler unit tests (real clock and real scheduler thread). In the GUI I verified the pop-up for a reminder that was already overdue at start-up; I did not sit and wait for a future reminder to fire in the GUI.

## Checklist from the specification

| # | Requirement | Result | How it was checked |
|---|---|---|---|
| 1 | Java 17 compatibility | PASSED | Compiled with `javac --release 17` on JDK 17.0.20; app launched on that JDK |
| 2 | Maven clean | **NOT RUN** | Maven unavailable; `rm -rf` of the output folders used instead |
| 3 | Maven compile | **NOT RUN** (equivalent passed) | `javac --release 17 -Xlint:all`: exit 0, no warnings |
| 4 | JUnit tests | PASSED (35/35) | JUnit 5 console launcher, see log below |
| 5 | Maven package | **NOT RUN** (equivalent passed) | Built a runnable jar by hand (`jar cfe`, dependencies merged) and started it with `java -jar`. This is not the output of the maven-shade-plugin |
| 6 | Database initialisation | PASSED | `DatabaseTest`; first GUI launch on an empty folder created `assistant.db` |
| 7 | Task CRUD | PASSED | `TaskServiceTest` (create, update, complete/reopen, delete, filters, search, validation, SQL-injection text); GUI: added a task through the dialog, saw the empty-title validation message |
| 8 | Notes CRUD | PASSED (unit level) | `NoteServiceTest`; the notes page was rendered in the GUI with data, but I did not drive note editing by mouse |
| 9 | Reminder creation and scheduling | PASSED | `ReminderServiceTest`: future-time validation, fires once, no duplicates with 6 concurrent claimers, rescheduling, real scheduler thread; GUI pop-up for a missed reminder |
| 10 | Chat history persistence | PASSED | `ChatServiceTest`, `PersistenceTest`; GUI shows earlier conversations after restart |
| 11 | Application start-up | PASSED (Linux) | Launched under Xvfb + Openbox, no exceptions in the log, screenshots of every page |
| 12 | Missing API key handling | PASSED | Unit tests; GUI shows the warning banner, "AI not configured" status, nothing is sent, typed text is kept, no fake reply is stored |
| 13 | Shutdown and reopen without data loss | PASSED | GUI: add task, close the window (exit code 0), reopen, task still listed; the row was also found by reading the `.db` file directly with another SQLite client |

## Problems found while verifying (all fixed and re-tested)

1. **Every database insert failed** with "not implemented by SQLite JDBC driver" because `getGeneratedKeys()` is not supported on prepared statements. Replaced by `SELECT last_insert_rowid()` on the same connection. (Found by the unit tests: 17 of 35 failed before the fix.)
2. **Dashboard crashed into its error banner** (NullPointerException): custom Swing components have no accessibility context. Removed those calls. (Found only by launching the real app.)
3. **Multi-line text boxes were invisible** (chat input, note body, descriptions) because they were detached from their scroll pane. Fixed. (Found only in screenshots.)
4. Driver registration made explicit (`Class.forName("org.sqlite.JDBC")`) so it also works in fat jars and test runners.
5. After a validation error in a dialog, focus now returns to the first text field.

## Commands executed and their output

Because Maven was unavailable, the stand-in commands were:

```
$ rm -rf build            # stand-in for: mvn clean
$ javac --release 17 -Xlint:all,-serial,-path -d out src/main/java/**/*.java   # stand-in for: mvn compile
exit code: 0  (62 source files, 0 warnings printed above)

$ javac --release 17 ... src/test/java/**/*.java   # stand-in for: mvn test-compile
exit code: 0  (10 test files)

$ java -jar junit-platform-console-standalone.jar --scan-classpath   # stand-in for: mvn test
.
+-- JUnit Platform Suite [OK]
+-- JUnit Jupiter [OK]
| +-- TaskServiceTest [OK]
| | +-- filtersAndSearch() [OK]
| | +-- rejectsInvalidInput() [OK]
| | +-- createReadUpdateDelete() [OK]
| | +-- completeAndReopen() [OK]
| | '-- sqlInjectionAttemptIsStoredAsPlainText() [OK]
| +-- ProviderTest [OK]
| | +-- parsesOpenAiAndAnthropicReplies() [OK]
| | +-- providersWithoutKeyRefuseToAnswer() [OK]
| | +-- openAiRequestBodyIsValidJsonWithEscaping() [OK]
| | +-- networkFailureBecomesFriendlyMessage() [OK]
| | +-- factoryPicksProvider() [OK]
| | '-- unexpectedReplyShapeIsAnError() [OK]
| +-- NoteServiceTest [OK]
| | +-- createUpdateSearchDelete() [OK]
| | '-- validation() [OK]
| +-- PersistenceTest [OK]
| | +-- dashboardReflectsDatabase(Path) [OK]
| | '-- dataSurvivesRestart(Path) [OK]
| +-- ChatServiceTest [OK]
| | +-- failedCallStoresNoFakeAssistantMessage() [OK]
| | +-- conversationRoundTripIsPersisted() [OK]
| | +-- missingApiKeyIsReportedNotFaked() [OK]
| | +-- clearAndDeleteAndValidation() [OK]
| | '-- contextIsLimitedAndStartsWithUserMessage() [OK]
| +-- ReminderServiceTest [OK]
| | +-- concurrentClaimsNeverDuplicate() [OK]
| | +-- dueReminderIsClaimedExactlyOnce() [OK]
| | +-- rejectsPastTimesAndEmptyTitles() [OK]
| | +-- createsAndListsUpcoming() [OK]
| | +-- reschedulingFiresAgainButRenamingDoesNot() [OK]
| | '-- backgroundSchedulerDeliversDueReminder() [OK]
| +-- AppConfigTest [OK]
| | +-- templateKeyPlaceholderCountsAsNotConfigured(Path) [OK]
| | +-- readsFileAndReloads(Path) [OK]
| | +-- notConfiguredByDefault(Path) [OK]
| | '-- environmentOverridesFile(Path) [OK]
| +-- JsonTest [OK]
| | +-- quoteRoundTrips() [OK]
| | +-- rejectsGarbage() [OK]
| | '-- parsesNestedStructures() [OK]
| '-- DatabaseTest [OK]
|   +-- initializeIsIdempotentAndForeignKeysAreEnforced(Path) [OK]
|   '-- createsFileAndAllTablesOnFirstLaunch(Path) [OK]
'-- JUnit Vintage [OK]
Test run finished after 5162 ms
[        12 containers found      ]
[         0 containers skipped    ]
[        12 containers started    ]
[         0 containers aborted    ]
[        12 containers successful ]
[         0 containers failed     ]
[        35 tests found           ]
[         0 tests skipped         ]
[        35 tests started         ]
[         0 tests aborted         ]
[        35 tests successful      ]
[         0 tests failed          ]
```

Other checks, performed with a virtual display and an Openbox window manager:

```
java -Dassistant.home=/tmp/home3 -jar app.jar        # first launch on an empty data folder
  -> app running after 5s: yes; assistant.db created automatically
  -> Alt+F4 (window-manager close request): process exited, exit code 0
add a task through the dialog, close, start again   -> task listed after restart
AI_API_KEY=... AI_BASE_URL=http://127.0.0.1:8765/v1 (mock server)
  -> request received at /v1/chat/completions with "Authorization: Bearer <key>", system prompt, user message
  -> reply shown as assistant bubble; second request carried the full history
  -> mock returned HTTP 429: UI showed "...too many requests... (429). Details: Rate limit reached (mock)",
     marked "Not saved", with a "Try again" button; no assistant message was stored
```

## How to repeat the checks yourself

```powershell
mvn clean
mvn compile
mvn test
mvn package
java -jar target\my-personal-ai-assistant.jar
```
