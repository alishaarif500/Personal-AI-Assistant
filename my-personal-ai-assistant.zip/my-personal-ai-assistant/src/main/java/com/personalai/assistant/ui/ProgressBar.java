package com.personalai.assistant.ui;

import javax.swing.JComponent;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/** Slim rounded progress bar. */
public class ProgressBar extends JComponent {
    private final int percent;

    public ProgressBar(int percent) {
        this.percent = Math.max(0, Math.min(100, percent));
        setPreferredSize(new Dimension(100, 12));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 12));
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int h = getHeight();
        g2.setColor(Theme.SURFACE_ALT);
        g2.fillRoundRect(0, 0, getWidth(), h, h, h);
        int w = (int) Math.round(getWidth() * percent / 100.0);
        if (w > 0) {
            g2.setColor(Theme.SUCCESS);
            g2.fillRoundRect(0, 0, Math.max(w, h), h, h, h);
        }
        g2.dispose();
    }
}
