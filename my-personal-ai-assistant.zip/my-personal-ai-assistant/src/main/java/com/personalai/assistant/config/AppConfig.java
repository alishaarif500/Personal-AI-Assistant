package com.personalai.assistant.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Properties;

/**
 * Application configuration and locations.
 *
 * <p>AI settings are read from environment variables (highest priority) or from
 * {@code config.properties} in the application data folder. API keys are never part of the source code.</p>
 */
public final class AppConfig {
    public static final String APP_NAME = "My Personal AI Assistant";
    public static final String APP_VERSION = "1.0.0";
    public static final String DEFAULT_PROVIDER = "openai";

    private final Path dataDir;
    private final Map<String, String> env;
    private Properties fileProps = new Properties();

    public AppConfig(Path dataDir, Map<String, String> env) {
        this.dataDir = dataDir;
        this.env = env;
        reload();
    }

    /** Creates the configuration for the real application (user data folder + real environment). */
    public static AppConfig forCurrentUser() {
        return new AppConfig(defaultDataDir(), System.getenv());
    }

    public static Path defaultDataDir() {
        String override = System.getProperty("assistant.home");
        if (override != null && !override.isBlank()) return Paths.get(override);
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            String appData = System.getenv("APPDATA");
            Path base = (appData != null && !appData.isBlank())
                    ? Paths.get(appData)
                    : Paths.get(System.getProperty("user.home"), "AppData", "Roaming");
            return base.resolve("MyPersonalAIAssistant");
        }
        return Paths.get(System.getProperty("user.home"), ".my-personal-ai-assistant");
    }

    public Path dataDir() { return dataDir; }
    public Path databaseFile() { return dataDir.resolve("assistant.db"); }
    public Path configFile() { return dataDir.resolve("config.properties"); }

    /** Re-reads config.properties (used by the "Reload configuration" button). */
    public synchronized void reload() {
        Properties p = new Properties();
        Path f = configFile();
        if (Files.isRegularFile(f)) {
            try (InputStream in = Files.newInputStream(f)) {
                p.load(in);
            } catch (IOException e) {
                // Unreadable config simply means "not configured"; the settings page shows the status.
            }
        }
        this.fileProps = p;
    }

    private synchronized String get(String envKey, String propKey, String def) {
        String v = env.get(envKey);
        if (v == null || v.isBlank()) v = fileProps.getProperty(propKey);
        if (v == null || v.isBlank()) return def;
        return v.strip();
    }

    public String provider() { return get("AI_PROVIDER", "ai.provider", DEFAULT_PROVIDER).toLowerCase(); }

    public String apiKey() {
        String k = get("AI_API_KEY", "ai.api.key", "");
        // Ignore the placeholder from config.properties.example
        return k.startsWith("PASTE_") || k.equalsIgnoreCase("your-api-key-here") ? "" : k;
    }

    public String baseUrl() {
        String def = provider().equals("anthropic") ? "https://api.anthropic.com/v1" : "https://api.openai.com/v1";
        String u = get("AI_BASE_URL", "ai.base.url", def);
        return u.endsWith("/") ? u.substring(0, u.length() - 1) : u;
    }

    public String model() {
        String def = provider().equals("anthropic") ? "claude-sonnet-5-5" : "gpt-4o-mini";
        return get("AI_MODEL", "ai.model", def);
    }

    public boolean isAiConfigured() { return !apiKey().isBlank(); }

    /** Where the key comes from, for the settings page. */
    public String apiKeySource() {
        if (env.get("AI_API_KEY") != null && !env.get("AI_API_KEY").isBlank()) return "environment variable AI_API_KEY";
        if (!apiKey().isBlank()) return "config.properties";
        return "not set";
    }

    public String maskedKey() {
        String k = apiKey();
        if (k.isEmpty()) return "(none)";
        if (k.length() <= 8) return "********";
        return k.substring(0, 3) + "…" + k.substring(k.length() - 4);
    }

    /** Writes a template config file if none exists yet. Returns true if a file was created. */
    public boolean createTemplateIfMissing() throws IOException {
        Files.createDirectories(dataDir);
        if (Files.exists(configFile())) return false;
        Properties p = new Properties();
        p.setProperty("ai.provider", DEFAULT_PROVIDER);
        p.setProperty("ai.api.key", "PASTE_YOUR_API_KEY_HERE");
        p.setProperty("ai.base.url", "");
        p.setProperty("ai.model", "");
        try (OutputStream out = Files.newOutputStream(configFile())) {
            p.store(out, "My Personal AI Assistant - keep this file private, never share your API key");
        }
        return true;
    }
}
