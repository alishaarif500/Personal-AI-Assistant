package com.personalai.assistant.ui;

import javax.swing.JComponent;
import javax.swing.Timer;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/** Animated three-dot "assistant is thinking" bubble. */
public class TypingIndicator extends JComponent {
    private int phase;
    private final Timer timer = new Timer(320, e -> { phase = (phase + 1) % 3; repaint(); });

    public TypingIndicator() {
        setOpaque(false);
        setPreferredSize(new Dimension(76, 40));
        setMaximumSize(new Dimension(76, 40));
        timer.start();
    }

    public void stop() { timer.stop(); }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Theme.ASSISTANT_BUBBLE);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
        g2.setColor(Theme.BORDER);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
        for (int i = 0; i < 3; i++) {
            g2.setColor(i == phase ? Theme.ACCENT : Theme.MUTED);
            int d = i == phase ? 10 : 8;
            g2.fillOval(20 + i * 17 - d / 2, getHeight() / 2 - d / 2, d, d);
        }
        g2.dispose();
    }
}
