package com.personalai.assistant.ui;

import com.personalai.assistant.model.Reminder;
import com.personalai.assistant.service.ReminderService;
import com.personalai.assistant.service.ValidationException;
import com.personalai.assistant.util.Dates;
import com.personalai.assistant.util.Text;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/** Reminder manager. Notifications themselves are fired by {@link ReminderService}'s scheduler. */
public class ReminderPanel extends JPanel implements Page {
    private final ReminderService service;
    private final VerticalList list = new VerticalList();
    private final JLabel summary = Ui.label(" ", Theme.small(), Theme.MUTED);

    public ReminderPanel(ReminderService service) {
        this.service = service;
        setLayout(new BorderLayout(0, 16));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 24, 32));

        ModernButton add = new ModernButton("New reminder", ModernButton.Kind.PRIMARY).withIcon(Icons.Type.PLUS);
        add.addActionListener(e -> openDialog(null));
        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        JPanel header = Ui.pageHeader("Reminders", "Get a pop-up notification at the right moment (while the app is running)", add);
        header.setAlignmentX(0f);
        top.add(header);
        top.add(Ui.vgap(10));
        summary.setAlignmentX(0f);
        top.add(summary);
        add(top, BorderLayout.NORTH);
        add(Ui.scroll(list), BorderLayout.CENTER);
    }

    @Override public void onShow() { refresh(); }

    /** Called by the main window when the scheduler just fired a reminder. */
    public void refresh() {
        list.removeAll();
        try {
            List<Reminder> all = service.listAll();
            long upcoming = all.stream().filter(r -> !r.notified()).count();
            summary.setText(upcoming + " upcoming · " + (all.size() - upcoming) + " past");
            if (all.isEmpty()) {
                list.add(Ui.emptyState(Icons.Type.BELL, "No reminders yet", "Click “New reminder” and pick a date and time."));
            }
            boolean pastHeaderAdded = false, upcomingHeaderAdded = false;
            LocalDate today = LocalDate.now();
            for (Reminder r : all) {
                if (!r.notified() && !upcomingHeaderAdded) { list.add(sectionLabel("Upcoming")); upcomingHeaderAdded = true; }
                if (r.notified() && !pastHeaderAdded) { list.add(sectionLabel("Past")); pastHeaderAdded = true; }
                list.add(row(r, today));
                list.add(Ui.vgap(8));
            }
        } catch (RuntimeException e) {
            summary.setText(" ");
            list.add(Ui.banner("Could not load reminders: " + e.getMessage(), Theme.DANGER, Theme.DANGER_SOFT));
        }
        list.revalidate();
        list.repaint();
    }

    private JComponent sectionLabel(String text) {
        JLabel l = Ui.label(text.toUpperCase(), Theme.smallBold(), Theme.MUTED);
        l.setAlignmentX(0f);
        l.setBorder(BorderFactory.createEmptyBorder(8, 2, 8, 0));
        return l;
    }

    private JComponent row(Reminder r, LocalDate today) {
        RowPanel row = new RowPanel();
        JLabel bell = new JLabel(Icons.of(Icons.Type.BELL, 26, r.notified() ? Theme.MUTED : Theme.ACCENT));
        row.add(bell, BorderLayout.WEST);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        JLabel title = Ui.label(Text.truncate(r.title(), 90), Theme.bold(), r.notified() ? Theme.MUTED : Theme.TEXT);
        title.setAlignmentX(0f);
        center.add(title);
        JPanel meta = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        meta.setOpaque(false);
        meta.setAlignmentX(0f);
        meta.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        meta.add(r.notified()
                ? Ui.badge("Notified", Theme.MUTED, Theme.SURFACE_ALT)
                : Ui.badge(Dates.friendly(r.remindAt(), today), Theme.ACCENT, Theme.ACCENT_SOFT));
        if (r.notified()) meta.add(Ui.label(Dates.dateTime(r.remindAt()), Theme.small(), Theme.MUTED));
        if (!r.description().isBlank()) meta.add(Ui.label("· " + Text.truncate(r.description(), 70), Theme.small(), Theme.MUTED));
        center.add(meta);
        row.add(center, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 2, 0));
        actions.setOpaque(false);
        IconButton edit = new IconButton(Icons.Type.EDIT, "Edit reminder", Theme.ACCENT);
        edit.addActionListener(e -> openDialog(r));
        IconButton del = new IconButton(Icons.Type.TRASH, "Delete reminder", Theme.DANGER);
        del.addActionListener(e -> delete(r));
        actions.add(edit);
        actions.add(del);
        row.add(actions, BorderLayout.EAST);
        return row;
    }

    private void delete(Reminder r) {
        if (!Ui.confirm(this, "Delete reminder?", "“" + Text.truncate(r.title(), 60) + "” will be permanently deleted.", "Delete", true)) return;
        try {
            service.delete(r.id());
        } catch (RuntimeException e) {
            Ui.message(this, "Could not delete reminder", e.getMessage(), true);
        }
        refresh();
    }

    private void openDialog(Reminder existing) {
        if (new ReminderDialog(this, existing).open()) refresh();
    }

    private final class ReminderDialog extends FormDialog {
        private final Reminder existing;
        private final JTextField title = new HintTextField("What should I remind you about?");
        private final JTextArea description = new HintTextArea(3, 20, "Add details…");
        private final JSpinner date;
        private final JSpinner time;

        ReminderDialog(Component parent, Reminder existing) {
            super(parent, existing == null ? "New reminder" : "Edit reminder", existing == null ? "Add reminder" : "Save changes");
            this.existing = existing;
            LocalDateTime initial = existing != null ? existing.remindAt()
                    : LocalDateTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0);
            date = dateSpinner(initial.toLocalDate());
            time = timeSpinner(initial.toLocalTime());
            if (existing != null) {
                title.setText(existing.title());
                description.setText(existing.description());
            }
            addField("Title", Ui.inputBox(title));
            addField("Description (optional)", Ui.textAreaBox(description, 80));
            JPanel when = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
            when.setOpaque(false);
            when.add(date);
            when.add(time);
            addField("Date and time", when);
        }

        @Override protected void doSave() throws ParseException {
            LocalDateTime at = LocalDateTime.of(readDate(date), readTime(time));
            if (existing == null) service.create(title.getText(), description.getText(), at);
            else service.update(existing.id(), title.getText(), description.getText(), at);
        }
    }
}
