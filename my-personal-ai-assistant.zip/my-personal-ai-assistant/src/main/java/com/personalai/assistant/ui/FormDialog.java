package com.personalai.assistant.ui;

import com.personalai.assistant.service.ValidationException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * Base class for the add/edit dialogs. Validation problems are shown inside the dialog and the dialog stays
 * open, so the user never loses what they typed.
 */
abstract class FormDialog extends JDialog {
    private boolean saved;
    private final JLabel errorLabel = Ui.label(" ", Theme.small(), Theme.DANGER);
    protected final JPanel body = new JPanel();

    FormDialog(Component parent, String title, String saveLabel) {
        super(SwingUtilities.getWindowAncestor(parent), title, ModalityType.APPLICATION_MODAL);
        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(Theme.SURFACE);
        root.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER), BorderFactory.createEmptyBorder(22, 26, 18, 26)));
        root.add(Ui.label(title, Theme.subheading(), Theme.TEXT), BorderLayout.NORTH);

        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        root.add(body, BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(errorLabel, BorderLayout.NORTH);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        buttons.setOpaque(false);
        ModernButton cancel = new ModernButton("Cancel", ModernButton.Kind.SECONDARY);
        cancel.addActionListener(e -> dispose());
        ModernButton save = new ModernButton(saveLabel, ModernButton.Kind.PRIMARY);
        save.addActionListener(e -> attemptSave());
        buttons.add(cancel);
        buttons.add(save);
        south.add(buttons, BorderLayout.SOUTH);
        root.add(south, BorderLayout.SOUTH);

        setContentPane(root);
        getRootPane().setDefaultButton(null);
        getRootPane().registerKeyboardAction(e -> dispose(),
                javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
        setResizable(false);
    }

    /** Called when "Save" is pressed. Throw {@link ValidationException} to show a message and keep the dialog open. */
    protected abstract void doSave() throws ParseException;

    private void attemptSave() {
        try {
            doSave();
            saved = true;
            dispose();
        } catch (ParseException e) {
            showError("Please enter a valid date/time (for example 2026-12-31 and 14:30).");
        } catch (ValidationException e) {
            showError(e.getMessage());
        } catch (RuntimeException e) {
            showError("Something went wrong: " + e.getMessage());
        }
    }

    protected void showError(String message) {
        errorLabel.setText("<html>" + Ui.escapeHtml(message) + "</html>");
        javax.swing.text.JTextComponent first = firstTextComponent(body);
        if (first != null) first.requestFocusInWindow(); // let the user fix the input right away
    }

    private static javax.swing.text.JTextComponent firstTextComponent(java.awt.Container c) {
        for (Component child : c.getComponents()) {
            if (child instanceof javax.swing.text.JTextComponent t && t.isEditable()) return t;
            if (child instanceof java.awt.Container sub) {
                javax.swing.text.JTextComponent found = firstTextComponent(sub);
                if (found != null) return found;
            }
        }
        return null;
    }

    protected void addField(String label, JComponent field) {
        JLabel l = Ui.label(label, Theme.smallBold(), Theme.MUTED);
        l.setAlignmentX(0f);
        l.setBorder(BorderFactory.createEmptyBorder(0, 2, 5, 0));
        field.setAlignmentX(0f);
        body.add(l);
        body.add(field);
        body.add(Ui.vgap(12));
    }

    /** Shows the dialog; returns true if the user saved. */
    boolean open() {
        pack();
        setSize(Math.max(480, getWidth()), getHeight());
        setLocationRelativeTo(getOwner());
        setVisible(true);
        return saved;
    }

    // ---- date / time spinner helpers ------------------------------------------------------

    static JSpinner dateSpinner(LocalDate initial) {
        JSpinner sp = new JSpinner(new SpinnerDateModel(toDate(initial.atStartOfDay()), null, null, java.util.Calendar.DAY_OF_MONTH));
        sp.setEditor(new JSpinner.DateEditor(sp, "yyyy-MM-dd"));
        return styleSpinner(sp);
    }

    static JSpinner timeSpinner(LocalTime initial) {
        JSpinner sp = new JSpinner(new SpinnerDateModel(toDate(LocalDateTime.of(2000, 1, 1, initial.getHour(), initial.getMinute())),
                null, null, java.util.Calendar.MINUTE));
        sp.setEditor(new JSpinner.DateEditor(sp, "HH:mm"));
        return styleSpinner(sp);
    }

    private static JSpinner styleSpinner(JSpinner sp) {
        sp.setFont(Theme.base());
        sp.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        sp.setPreferredSize(new Dimension(150, 38));
        JSpinner.DefaultEditor ed = (JSpinner.DefaultEditor) sp.getEditor();
        ed.getTextField().setBackground(Theme.INPUT_BG);
        ed.getTextField().setForeground(Theme.TEXT);
        ed.getTextField().setCaretColor(Theme.TEXT);
        ed.getTextField().setFont(Theme.base());
        ed.getTextField().setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 4));
        return sp;
    }

    static LocalDate readDate(JSpinner sp) throws ParseException {
        sp.commitEdit();
        return ((Date) sp.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    static LocalTime readTime(JSpinner sp) throws ParseException {
        sp.commitEdit();
        return ((Date) sp.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalTime().withSecond(0).withNano(0);
    }

    private static Date toDate(LocalDateTime dt) { return Date.from(dt.atZone(ZoneId.systemDefault()).toInstant()); }
}
