package com.personalai.assistant.ui;

import com.personalai.assistant.model.Note;
import com.personalai.assistant.service.NoteService;
import com.personalai.assistant.util.Dates;
import com.personalai.assistant.util.Text;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.time.LocalDateTime;
import java.util.List;

/** Notes manager: searchable list on the left, editor on the right. */
public class NotesPanel extends JPanel implements Page {
    private final NoteService service;
    private final DefaultListModel<Note> model = new DefaultListModel<>();
    private final JList<Note> jlist = new JList<>(model);
    private final JTextField search = new HintTextField("Search notes…");
    private final JTextField titleField = new HintTextField("Note title");
    private final JTextArea content = new HintTextArea(10, 30, "Start writing…");
    private final JLabel status = Ui.label(" ", Theme.small(), Theme.MUTED);
    private final ModernButton saveButton = new ModernButton("Save note", ModernButton.Kind.PRIMARY).withIcon(Icons.Type.CHECK);
    private final ModernButton deleteButton = new ModernButton("Delete", ModernButton.Kind.DANGER).withIcon(Icons.Type.TRASH);
    private final JPanel listCards = new JPanel(new CardLayout());
    private final JLabel countLabel = Ui.label(" ", Theme.small(), Theme.MUTED);

    private Note current;      // null = a brand-new note that has not been saved yet
    private boolean dirty;
    private boolean loading;
    private final Timer debounce;

    public NotesPanel(NoteService service) {
        this.service = service;
        setLayout(new BorderLayout(0, 16));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 24, 32));

        ModernButton newNote = new ModernButton("New note", ModernButton.Kind.PRIMARY).withIcon(Icons.Type.PLUS);
        newNote.addActionListener(e -> startNewNote());
        add(Ui.pageHeader("Notes", "Capture ideas and keep them searchable", newNote), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(16, 0));
        body.setOpaque(false);
        body.add(buildListCard(), BorderLayout.WEST);
        body.add(buildEditorCard(), BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);

        debounce = new Timer(250, e -> reloadList(current == null ? 0 : current.id()));
        debounce.setRepeats(false);
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { debounce.restart(); }
            @Override public void removeUpdate(DocumentEvent e) { debounce.restart(); }
            @Override public void changedUpdate(DocumentEvent e) { debounce.restart(); }
        });
        showNote(null);
    }

    private JComponent buildListCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 10));
        card.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        card.setPreferredSize(new Dimension(330, 100));
        search.setToolTipText("Search notes by title or content");
        JPanel top = new JPanel(new BorderLayout(0, 6));
        top.setOpaque(false);
        top.add(Ui.inputBox(search), BorderLayout.NORTH);
        top.add(countLabel, BorderLayout.SOUTH);
        card.add(top, BorderLayout.NORTH);

        jlist.setOpaque(false);
        jlist.setBackground(Theme.SURFACE);
        jlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jlist.setFixedCellHeight(-1);
        jlist.setCellRenderer(new NoteRenderer());
        jlist.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || loading) return;
            Note sel = jlist.getSelectedValue();
            if (sel == null) return;
            if (current != null && sel.id() == current.id()) return;
            if (!confirmDiscard()) {
                loading = true;
                selectById(current == null ? 0 : current.id());
                loading = false;
                return;
            }
            showNote(sel);
        });
        listCards.setOpaque(false);
        listCards.add(Ui.scroll(jlist), "list");
        listCards.add(Ui.emptyState(Icons.Type.NOTES, "No notes", "Write your first note on the right."), "empty");
        card.add(listCards, BorderLayout.CENTER);
        return card;
    }

    private JComponent buildEditorCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 12));
        card.setBorder(BorderFactory.createEmptyBorder(18, 18, 14, 18));
        JPanel top = new JPanel(new BorderLayout(0, 6));
        top.setOpaque(false);
        titleField.setFont(Theme.subheading());
        RoundedPanel titleBox = Ui.inputBox(titleField);
        titleField.setFont(Theme.subheading());
        top.add(titleBox, BorderLayout.CENTER);
        card.add(top, BorderLayout.NORTH);

        RoundedPanel contentBox = Ui.textAreaBox(content, 200);
        card.add(contentBox, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.add(status, BorderLayout.WEST);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        buttons.add(deleteButton);
        buttons.add(saveButton);
        bottom.add(buttons, BorderLayout.EAST);
        card.add(bottom, BorderLayout.SOUTH);

        saveButton.addActionListener(e -> save());
        deleteButton.addActionListener(e -> deleteCurrent());
        DocumentListener dirtyListener = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { markDirty(); }
            @Override public void removeUpdate(DocumentEvent e) { markDirty(); }
            @Override public void changedUpdate(DocumentEvent e) { markDirty(); }
        };
        titleField.getDocument().addDocumentListener(dirtyListener);
        content.getDocument().addDocumentListener(dirtyListener);
        card.getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control S"), "saveNote");
        card.getActionMap().put("saveNote", new javax.swing.AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { save(); }
        });
        return card;
    }

    @Override public void onShow() { reloadList(current == null ? 0 : current.id()); }

    private void markDirty() {
        if (loading) return;
        dirty = true;
        status.setText("Unsaved changes");
    }

    private boolean confirmDiscard() {
        return !dirty || Ui.confirm(this, "Discard changes?", "You have unsaved changes in this note. Discard them?", "Discard", true);
    }

    private void reloadList(long selectId) {
        try {
            List<Note> notes = service.search(search.getText());
            loading = true;
            model.clear();
            notes.forEach(model::addElement);
            selectById(selectId);
            loading = false;
            boolean searching = Text.trimToNull(search.getText()) != null;
            countLabel.setText(notes.size() + (notes.size() == 1 ? " note" : " notes"));
            ((CardLayout) listCards.getLayout()).show(listCards, notes.isEmpty() ? "empty" : "list");
            if (notes.isEmpty() && searching) countLabel.setText("No notes match your search");
        } catch (RuntimeException e) {
            loading = false;
            countLabel.setText("Could not load notes");
            Ui.message(this, "Could not load notes", e.getMessage(), true);
        }
    }

    private void selectById(long id) {
        if (id == 0) { jlist.clearSelection(); return; }
        for (int i = 0; i < model.size(); i++) {
            if (model.get(i).id() == id) {
                jlist.setSelectedIndex(i);
                jlist.ensureIndexIsVisible(i);
                return;
            }
        }
        jlist.clearSelection();
    }

    private void startNewNote() {
        if (!confirmDiscard()) return;
        loading = true;
        jlist.clearSelection();
        loading = false;
        showNote(null);
        titleField.requestFocusInWindow();
    }

    private void showNote(Note n) {
        loading = true;
        current = n;
        titleField.setText(n == null ? "" : n.title());
        content.setText(n == null ? "" : n.content());
        content.setCaretPosition(0);
        dirty = false;
        deleteButton.setEnabled(n != null);
        status.setText(n == null ? "New note" : "Created " + Dates.dateTime(n.createdAt()) + "  ·  Updated " + Dates.dateTime(n.updatedAt()));
        loading = false;
    }

    private void save() {
        try {
            Note saved;
            if (current == null) {
                saved = service.create(titleField.getText(), content.getText());
            } else {
                service.update(current.id(), titleField.getText(), content.getText());
                saved = service.get(current.id());
            }
            showNote(saved);
            reloadList(saved.id());
            status.setText("Saved at " + Dates.TIME_SECONDS.format(LocalDateTime.now()));
        } catch (RuntimeException e) {
            Ui.message(this, "Could not save note", e.getMessage(), true);
        }
    }

    private void deleteCurrent() {
        if (current == null) return;
        if (!Ui.confirm(this, "Delete note?", "“" + Text.truncate(current.title(), 60) + "” will be permanently deleted.", "Delete", true)) return;
        try {
            service.delete(current.id());
            showNote(null);
            reloadList(0);
        } catch (RuntimeException e) {
            Ui.message(this, "Could not delete note", e.getMessage(), true);
        }
    }

    private static final class NoteRenderer extends JPanel implements ListCellRenderer<Note> {
        private final JLabel title = new JLabel();
        private final JLabel snippet = new JLabel();
        private final JLabel date = new JLabel();

        NoteRenderer() {
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            title.setFont(Theme.bold());
            snippet.setFont(Theme.small());
            date.setFont(Theme.small());
            add(title);
            add(Ui.vgap(2));
            add(snippet);
            add(Ui.vgap(2));
            add(date);
        }

        @Override
        public java.awt.Component getListCellRendererComponent(JList<? extends Note> list, Note n, int index, boolean selected, boolean focus) {
            title.setText(Text.truncate(n.title(), 34));
            snippet.setText(n.content().isBlank() ? "No content" : Text.truncate(n.content(), 44));
            date.setText(Dates.dateTime(n.updatedAt()));
            Color bg = selected ? Theme.ACCENT_SOFT : Theme.SURFACE;
            setBackground(bg);
            setOpaque(true);
            title.setForeground(Theme.TEXT);
            snippet.setForeground(Theme.MUTED);
            date.setForeground(Theme.MUTED);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER), BorderFactory.createEmptyBorder(9, 10, 9, 10)));
            return this;
        }
    }
}
