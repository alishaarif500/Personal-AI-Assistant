package com.personalai.assistant;

import com.personalai.assistant.model.Priority;
import com.personalai.assistant.model.Task;
import com.personalai.assistant.model.TaskFilter;
import com.personalai.assistant.service.TaskService;
import com.personalai.assistant.service.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {
    TaskService tasks;

    @BeforeEach
    void setUp(@TempDir Path dir) { tasks = TestSupport.newContext(dir).tasks; }

    @Test
    void createReadUpdateDelete() {
        Task t = tasks.create("  Write report ", "intro + summary", Priority.HIGH, LocalDate.now());
        assertEquals("Write report", t.title());
        assertFalse(t.completed());
        assertEquals(1, tasks.list(TaskFilter.ALL, null).size());

        tasks.update(t.id(), "Write final report", "", Priority.LOW, null);
        Task u = tasks.get(t.id());
        assertEquals("Write final report", u.title());
        assertEquals(Priority.LOW, u.priority());
        assertNull(u.dueDate());

        tasks.delete(t.id());
        assertNull(tasks.get(t.id()));
        assertThrows(ValidationException.class, () -> tasks.delete(t.id()));
    }

    @Test
    void completeAndReopen() {
        Task t = tasks.create("Pay bill", "", Priority.MEDIUM, null);
        tasks.setCompleted(t.id(), true);
        assertTrue(tasks.get(t.id()).completed());
        assertNotNull(tasks.get(t.id()).completedAt());
        tasks.setCompleted(t.id(), false);
        assertFalse(tasks.get(t.id()).completed());
        assertNull(tasks.get(t.id()).completedAt());
    }

    @Test
    void filtersAndSearch() {
        Task a = tasks.create("Alpha", "first", Priority.HIGH, LocalDate.now());
        Task b = tasks.create("Beta", "100% done_ish", Priority.LOW, LocalDate.now().plusDays(3));
        tasks.create("Gamma", "", Priority.HIGH, null);
        tasks.setCompleted(b.id(), true);

        assertEquals(3, tasks.list(TaskFilter.ALL, null).size());
        assertEquals(2, tasks.list(TaskFilter.PENDING, null).size());
        assertEquals(1, tasks.list(TaskFilter.COMPLETED, null).size());
        assertEquals(2, tasks.list(TaskFilter.HIGH_PRIORITY, null).size());
        assertEquals(1, tasks.list(TaskFilter.TODAY, null).size());
        assertEquals(a.id(), tasks.list(TaskFilter.TODAY, null).get(0).id());
        assertEquals(1, tasks.list(TaskFilter.ALL, "alp").size());
        // LIKE wildcards typed by the user are treated literally
        assertEquals(1, tasks.list(TaskFilter.ALL, "100%").size());
        assertEquals(0, tasks.list(TaskFilter.ALL, "%zzz").size());
        assertEquals(1, tasks.deleteCompleted());
    }

    @Test
    void rejectsInvalidInput() {
        assertThrows(ValidationException.class, () -> tasks.create("   ", "", Priority.LOW, null));
        assertThrows(ValidationException.class, () -> tasks.create(null, "", Priority.LOW, null));
        assertThrows(ValidationException.class, () -> tasks.create("x".repeat(151), "", Priority.LOW, null));
        assertThrows(ValidationException.class, () -> tasks.update(12345, "ok", "", Priority.LOW, null));
        assertThrows(ValidationException.class, () -> tasks.setCompleted(12345, true));
    }

    @Test
    void sqlInjectionAttemptIsStoredAsPlainText() {
        Task t = tasks.create("x'); DROP TABLE tasks;--", "", Priority.LOW, null);
        assertEquals("x'); DROP TABLE tasks;--", tasks.get(t.id()).title());
        assertEquals(1, tasks.list(TaskFilter.ALL, null).size());
    }
}
