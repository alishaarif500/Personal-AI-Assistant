package com.personalai.assistant.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record Task(long id, String title, String description, Priority priority, LocalDate dueDate,
                   LocalDateTime createdAt, boolean completed, LocalDateTime completedAt) {
    public boolean isOverdue(LocalDate today) {
        return !completed && dueDate != null && dueDate.isBefore(today);
    }
}
