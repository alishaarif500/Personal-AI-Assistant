package com.personalai.assistant;

import com.personalai.assistant.db.Database;
import com.personalai.assistant.model.Reminder;
import com.personalai.assistant.repository.ReminderRepository;
import com.personalai.assistant.service.ReminderService;
import com.personalai.assistant.service.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

class ReminderServiceTest {
    final AtomicReference<LocalDateTime> now = new AtomicReference<>(LocalDateTime.of(2030, 1, 1, 9, 0));
    ReminderService svc;
    ReminderRepository repo;

    @BeforeEach
    void setUp(@TempDir Path dir) {
        Database db = new Database(dir.resolve("r.db"));
        db.initialize();
        repo = new ReminderRepository(db);
        svc = new ReminderService(repo, now::get);
    }

    @Test
    void createsAndListsUpcoming() {
        Reminder r = svc.create("Call mum", "evening", now.get().plusHours(2));
        assertEquals(1, svc.upcoming(10).size());
        assertEquals(r.id(), svc.upcoming(10).get(0).id());
        assertFalse(svc.get(r.id()).notified());
    }

    @Test
    void rejectsPastTimesAndEmptyTitles() {
        assertThrows(ValidationException.class, () -> svc.create("x", "", now.get().minusMinutes(1)));
        assertThrows(ValidationException.class, () -> svc.create("x", "", now.get()));
        assertThrows(ValidationException.class, () -> svc.create(" ", "", now.get().plusDays(1)));
        assertThrows(ValidationException.class, () -> svc.create("x", "", null));
    }

    @Test
    void dueReminderIsClaimedExactlyOnce() {
        svc.create("Meeting", "", now.get().plusMinutes(30));
        assertTrue(svc.claimDue().isEmpty(), "not due yet");
        now.set(now.get().plusMinutes(31));
        List<Reminder> first = svc.claimDue();
        assertEquals(1, first.size());
        assertTrue(svc.claimDue().isEmpty(), "must never notify twice");
        assertTrue(svc.listAll().get(0).notified());
        assertEquals(0, svc.upcoming(10).size());
    }

    @Test
    void reschedulingFiresAgainButRenamingDoesNot() {
        Reminder r = svc.create("Stand-up", "", now.get().plusMinutes(5));
        now.set(now.get().plusMinutes(10));
        assertEquals(1, svc.claimDue().size());

        svc.update(r.id(), "Stand-up (renamed)", "", r.remindAt());       // same time, past -> allowed, stays notified
        assertTrue(svc.claimDue().isEmpty());

        assertThrows(ValidationException.class, () -> svc.update(r.id(), "x", "", now.get().minusMinutes(1)));
        svc.update(r.id(), "Stand-up", "", now.get().plusMinutes(5));      // new future time -> fires again
        assertFalse(svc.get(r.id()).notified());
        now.set(now.get().plusMinutes(6));
        assertEquals(1, svc.claimDue().size());
    }

    @Test
    void concurrentClaimsNeverDuplicate() throws Exception {
        svc.create("Race", "", now.get().plusMinutes(1));
        now.set(now.get().plusMinutes(2));
        List<Reminder> all = new CopyOnWriteArrayList<>();
        CountDownLatch go = new CountDownLatch(1);
        Thread[] ts = new Thread[6];
        for (int i = 0; i < ts.length; i++) {
            ts[i] = new Thread(() -> {
                try { go.await(); } catch (InterruptedException ignored) { }
                all.addAll(svc.claimDue());
            });
            ts[i].start();
        }
        go.countDown();
        for (Thread t : ts) t.join();
        assertEquals(1, all.size());
    }

    @Test
    void backgroundSchedulerDeliversDueReminder() throws Exception {
        ReminderService real = new ReminderService(repo); // real clock
        repo.insert("Overdue while app was closed", "", LocalDateTime.now().minusMinutes(5));
        CountDownLatch latch = new CountDownLatch(1);
        List<Reminder> got = new CopyOnWriteArrayList<>();
        real.start(r -> { got.add(r); latch.countDown(); }, 1);
        try {
            assertTrue(latch.await(10, TimeUnit.SECONDS), "scheduler did not fire");
        } finally {
            real.stop();
        }
        Thread.sleep(2500); // would fire again within this window if there were a bug
        assertEquals(1, got.size());
    }
}
