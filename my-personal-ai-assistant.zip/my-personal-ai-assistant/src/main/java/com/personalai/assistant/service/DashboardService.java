package com.personalai.assistant.service;

import com.personalai.assistant.model.Conversation;
import com.personalai.assistant.model.Note;
import com.personalai.assistant.model.Reminder;
import com.personalai.assistant.model.Task;
import com.personalai.assistant.model.TaskFilter;
import com.personalai.assistant.repository.ChatRepository;
import com.personalai.assistant.repository.NoteRepository;
import com.personalai.assistant.repository.ReminderRepository;
import com.personalai.assistant.repository.TaskRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/** Collects everything the dashboard shows, straight from the database. */
public class DashboardService {
    public record Snapshot(int totalTasks, int pendingTasks, int completedTasks, int dueToday, int overdue,
                           int upcomingReminders, List<Task> todayTasks, List<Reminder> reminders,
                           List<Note> recentNotes, List<Conversation> recentChats,
                           Map<LocalDate, Integer> completedLast7Days) {
        public int completionPercent() { return totalTasks == 0 ? 0 : Math.round(100f * completedTasks / totalTasks); }
    }

    private final TaskRepository tasks;
    private final ReminderRepository reminders;
    private final NoteRepository notes;
    private final ChatRepository chats;

    public DashboardService(TaskRepository tasks, ReminderRepository reminders, NoteRepository notes, ChatRepository chats) {
        this.tasks = tasks;
        this.reminders = reminders;
        this.notes = notes;
        this.chats = chats;
    }

    public Snapshot load() {
        LocalDate today = LocalDate.now();
        LocalDateTime now = LocalDateTime.now();
        int total = tasks.count("");
        int pending = tasks.count("status='PENDING'");
        int done = tasks.count("status='COMPLETED'");
        int dueToday = tasks.count("status='PENDING' AND due_date = ?", today.toString());
        int overdue = tasks.count("status='PENDING' AND due_date < ?", today.toString());
        return new Snapshot(total, pending, done, dueToday, overdue, reminders.countUpcoming(now),
                tasks.find(TaskFilter.TODAY, null, today), reminders.findUpcoming(now, 5),
                notes.search(null, 4), chats.conversations(4), tasks.completedPerDay(today, 7));
    }
}
