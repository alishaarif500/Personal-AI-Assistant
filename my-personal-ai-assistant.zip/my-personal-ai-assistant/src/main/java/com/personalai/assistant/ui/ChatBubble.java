package com.personalai.assistant.ui;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.util.function.IntSupplier;

/** A rounded, selectable message bubble that wraps its text to a maximum width. */
public class ChatBubble extends JPanel {
    private final JTextArea area = new JTextArea();
    private final Color fill;
    private final Color line;
    private final IntSupplier maxWidth;

    public ChatBubble(String text, Color fill, Color line, Color textColor, IntSupplier maxWidth) {
        super(new BorderLayout());
        this.fill = fill;
        this.line = line;
        this.maxWidth = maxWidth;
        setOpaque(false);
        area.setText(text);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setOpaque(false);
        area.setFont(Theme.base());
        area.setForeground(textColor);
        area.setSelectionColor(Theme.ACCENT);
        area.setSelectedTextColor(Color.WHITE);
        area.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        add(area, BorderLayout.CENTER);
    }

    @Override public Dimension getPreferredSize() {
        int max = Math.max(240, maxWidth.getAsInt());
        FontMetrics fm = area.getFontMetrics(area.getFont());
        int natural = 0;
        for (String l : area.getText().split("\n", -1)) natural = Math.max(natural, fm.stringWidth(l));
        Insets in = area.getInsets();
        int w = Math.max(70, Math.min(max, natural + in.left + in.right + 6));
        area.setSize(w, Short.MAX_VALUE);
        return new Dimension(w, area.getPreferredSize().height);
    }

    @Override public Dimension getMaximumSize() { return getPreferredSize(); }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(fill);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
        if (line != null) {
            g2.setColor(line);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
