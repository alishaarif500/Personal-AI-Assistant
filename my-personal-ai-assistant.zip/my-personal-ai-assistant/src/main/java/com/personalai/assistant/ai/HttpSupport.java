package com.personalai.assistant.ai;

import com.personalai.assistant.util.Json;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;

/** Shared HTTP plumbing and friendly error translation for providers. */
final class HttpSupport {
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private HttpSupport() {}

    static Object postJson(String url, Map<String, String> headers, String body) throws AiException {
        HttpRequest.Builder rb;
        try {
            rb = HttpRequest.newBuilder(URI.create(url));
        } catch (IllegalArgumentException e) {
            throw new AiException("The AI base URL is not valid: " + url);
        }
        rb.timeout(Duration.ofSeconds(90)).header("Content-Type", "application/json");
        headers.forEach(rb::header);
        rb.POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8));
        HttpResponse<String> resp;
        try {
            resp = CLIENT.send(rb.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new AiException("The request was cancelled.");
        } catch (HttpTimeoutException e) {
            throw new AiException("The AI provider took too long to answer. Please try again.", e);
        } catch (UnknownHostException | ConnectException e) {
            throw new AiException("Could not reach the AI provider. Please check your internet connection.", e);
        } catch (IOException e) {
            throw new AiException("Network problem while contacting the AI provider: " + e.getMessage(), e);
        }
        Object parsed = null;
        try {
            parsed = Json.parse(resp.body());
        } catch (RuntimeException ignored) {
            // handled below
        }
        if (resp.statusCode() / 100 != 2) {
            throw new AiException(describeError(resp.statusCode(), parsed));
        }
        if (parsed == null) throw new AiException("The AI provider returned a response that could not be understood.");
        return parsed;
    }

    private static String describeError(int status, Object parsed) {
        String detail = null;
        Map<String, Object> obj = Json.asObject(parsed);
        if (obj != null) {
            Map<String, Object> err = Json.asObject(obj.get("error"));
            if (err != null && err.get("message") instanceof String m) detail = m;
            else if (obj.get("error") instanceof String m) detail = m;
        }
        String base = switch (status) {
            case 400 -> "The AI provider rejected the request (400).";
            case 401, 403 -> "The AI provider rejected your API key (" + status + "). Check that the key is correct and active.";
            case 404 -> "The AI provider could not find the requested model or endpoint (404). Check ai.model and ai.base.url.";
            case 429 -> "The AI provider says you are sending too many requests or are out of quota (429).";
            default -> status >= 500 ? "The AI provider is having problems right now (" + status + "). Try again later."
                    : "The AI provider returned an error (" + status + ").";
        };
        return detail == null ? base : base + " Details: " + detail;
    }
}
