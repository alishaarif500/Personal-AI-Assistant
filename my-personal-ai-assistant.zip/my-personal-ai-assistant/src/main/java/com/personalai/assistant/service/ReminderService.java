package com.personalai.assistant.service;

import com.personalai.assistant.model.Reminder;
import com.personalai.assistant.repository.ReminderRepository;
import com.personalai.assistant.util.Text;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * CRUD plus the background scheduler. Every few seconds the scheduler looks for due reminders and
 * claims each one with an atomic database update, so a reminder can never be announced twice.
 * Reminders that came due while the app was closed are announced right after the next start.
 */
public class ReminderService {
    public static final int MAX_TITLE = 150;
    public static final int MAX_DESCRIPTION = 2000;

    private final ReminderRepository repo;
    private final Supplier<LocalDateTime> clock;
    private ScheduledExecutorService scheduler;

    public ReminderService(ReminderRepository repo) { this(repo, () -> LocalDateTime.now()); }

    public ReminderService(ReminderRepository repo, Supplier<LocalDateTime> clock) {
        this.repo = repo;
        this.clock = clock;
    }

    public Reminder create(String title, String description, LocalDateTime at) {
        String t = validateTitle(title);
        String d = validateDescription(description);
        if (at == null) throw new ValidationException("Please choose a date and time.");
        if (!at.isAfter(clock.get())) throw new ValidationException("The reminder time must be in the future.");
        return repo.insert(t, d, at.withSecond(0).withNano(0));
    }

    public void update(long id, String title, String description, LocalDateTime at) {
        String t = validateTitle(title);
        String d = validateDescription(description);
        if (at == null) throw new ValidationException("Please choose a date and time.");
        Reminder existing = repo.findById(id);
        if (existing == null) throw new ValidationException("This reminder no longer exists.");
        LocalDateTime normalized = at.withSecond(0).withNano(0);
        boolean timeChanged = !normalized.equals(existing.remindAt());
        if (timeChanged && !normalized.isAfter(clock.get())) {
            throw new ValidationException("The reminder time must be in the future.");
        }
        repo.update(id, t, d, normalized);
    }

    public void delete(long id) {
        if (!repo.delete(id)) throw new ValidationException("This reminder no longer exists.");
    }

    public Reminder get(long id) { return repo.findById(id); }
    public List<Reminder> listAll() { return repo.findAll(); }
    public List<Reminder> upcoming(int limit) { return repo.findUpcoming(clock.get(), limit); }

    /** Claims and returns reminders that are due now (each reminder is returned at most once, ever). */
    public List<Reminder> claimDue() {
        List<Reminder> claimed = new java.util.ArrayList<>();
        for (Reminder r : repo.findDue(clock.get())) {
            if (repo.markNotified(r.id())) claimed.add(r);
        }
        return claimed;
    }

    /** Starts the background check. {@code onDue} is called from a background thread. */
    public synchronized void start(Consumer<Reminder> onDue, long periodSeconds) {
        if (scheduler != null) return;
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "reminder-scheduler");
            t.setDaemon(true);
            return t;
        });
        scheduler.scheduleWithFixedDelay(() -> {
            try {
                for (Reminder r : claimDue()) onDue.accept(r);
            } catch (RuntimeException e) {
                System.err.println("Reminder check failed: " + e.getMessage()); // never kill the scheduler
            }
        }, 1, periodSeconds, TimeUnit.SECONDS);
    }

    public synchronized void stop() {
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
    }

    private static String validateTitle(String title) {
        String t = Text.trimToNull(title);
        if (t == null) throw new ValidationException("Please enter a reminder title.");
        if (t.length() > MAX_TITLE) throw new ValidationException("The reminder title is too long (maximum " + MAX_TITLE + " characters).");
        return t;
    }

    private static String validateDescription(String d) {
        String s = d == null ? "" : d.strip();
        if (s.length() > MAX_DESCRIPTION) throw new ValidationException("The description is too long (maximum " + MAX_DESCRIPTION + " characters).");
        return s;
    }
}
