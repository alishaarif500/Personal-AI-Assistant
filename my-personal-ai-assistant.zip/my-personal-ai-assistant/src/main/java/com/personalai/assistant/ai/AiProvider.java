package com.personalai.assistant.ai;

import com.personalai.assistant.model.ChatMessage;

import java.util.List;

/** Abstraction over an AI back end. Implement this interface to add another provider. */
public interface AiProvider {
    String id();

    String displayName();

    boolean isConfigured();

    /** Sends the conversation (oldest first, ending with the new user message) and returns the reply text. */
    String complete(List<ChatMessage> history) throws AiException;
}
