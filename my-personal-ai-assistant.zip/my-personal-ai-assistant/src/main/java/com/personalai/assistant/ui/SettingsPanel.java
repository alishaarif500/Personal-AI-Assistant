package com.personalai.assistant.ui;

import com.personalai.assistant.AppContext;
import com.personalai.assistant.config.AppConfig;
import com.personalai.assistant.model.TaskFilter;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;

/** Settings: appearance, AI configuration help, app/database info and safe data management. */
public class SettingsPanel extends JPanel implements Page {
    private final AppContext ctx;
    private final Consumer<Theme.Mode> onThemeChange;
    private final Runnable onAiConfigChanged;
    private final VerticalList content = new VerticalList();

    public SettingsPanel(AppContext ctx, Consumer<Theme.Mode> onThemeChange, Runnable onAiConfigChanged) {
        this.ctx = ctx;
        this.onThemeChange = onThemeChange;
        this.onAiConfigChanged = onAiConfigChanged;
        setLayout(new BorderLayout(0, 16));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 12, 24));
        add(Ui.pageHeader("Settings", "Appearance, AI provider and your data"), BorderLayout.NORTH);
        add(Ui.scroll(content), BorderLayout.CENTER);
    }

    @Override public void onShow() { rebuild(); }

    private void rebuild() {
        content.removeAll();
        content.add(appearanceCard());
        content.add(Ui.vgap(16));
        content.add(aiCard());
        content.add(Ui.vgap(16));
        content.add(databaseCard());
        content.add(Ui.vgap(16));
        content.add(dataCard());
        content.add(Ui.vgap(16));
        content.add(aboutCard());
        content.add(Ui.vgap(12));
        content.revalidate();
        content.repaint();
    }

    // ------------------------------------------------------------------ sections

    private RoundedPanel card(String title, String subtitle) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 12));
        card.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        card.setAlignmentX(0f);
        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        JLabel t = Ui.label(title, Theme.subheading(), Theme.TEXT);
        t.setAlignmentX(0f);
        head.add(t);
        if (subtitle != null) {
            JLabel s = Ui.label(subtitle, Theme.small(), Theme.MUTED);
            s.setAlignmentX(0f);
            head.add(Ui.vgap(2));
            head.add(s);
        }
        card.add(head, BorderLayout.NORTH);
        card.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        return card;
    }

    private JPanel column() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }

    private JComponent kv(String key, String value) {
        JPanel row = new JPanel(new BorderLayout(12, 0));
        row.setOpaque(false);
        row.setAlignmentX(0f);
        row.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
        JLabel k = Ui.label(key, Theme.base(), Theme.MUTED);
        k.setPreferredSize(new java.awt.Dimension(150, 22));
        row.add(k, BorderLayout.WEST);
        JLabel v = Ui.label(value, Theme.base(), Theme.TEXT);
        v.setToolTipText(value);
        row.add(v, BorderLayout.CENTER);
        row.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 30));
        return row;
    }

    private JComponent buttons(ModernButton... bs) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        p.setOpaque(false);
        p.setAlignmentX(0f);
        for (ModernButton b : bs) p.add(b);
        p.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 46));
        return p;
    }

    private JComponent appearanceCard() {
        RoundedPanel card = card("Appearance", "Choose the look that is most comfortable for your eyes");
        JPanel body = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        body.setOpaque(false);
        ButtonGroup g = new ButtonGroup();
        for (Theme.Mode m : Theme.Mode.values()) {
            Chip chip = new Chip(m == Theme.Mode.LIGHT ? "Light" : "Dark");
            chip.setSelected(Theme.mode == m);
            chip.addActionListener(e -> { if (Theme.mode != m) onThemeChange.accept(m); });
            g.add(chip);
            body.add(chip);
        }
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JComponent aiCard() {
        AppConfig cfg = ctx.config;
        RoundedPanel card = card("AI provider", "The chat assistant needs an API key. Tasks, reminders and notes work without one.");
        JPanel body = column();
        boolean ok = cfg.isAiConfigured();
        JPanel statusRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        statusRow.setOpaque(false);
        statusRow.setAlignmentX(0f);
        statusRow.add(ok ? Ui.badge("Configured", Theme.SUCCESS, Theme.SUCCESS_SOFT) : Ui.badge("Not configured", Theme.WARNING, Theme.WARNING_SOFT));
        body.add(statusRow);
        body.add(Ui.vgap(8));
        body.add(kv("Provider", cfg.provider()));
        body.add(kv("Model", cfg.model()));
        body.add(kv("Base URL", cfg.baseUrl()));
        body.add(kv("API key", ok ? cfg.maskedKey() + "  (from " + cfg.apiKeySource() + ")" : "not set"));
        body.add(kv("Config file", cfg.configFile().toString()));
        body.add(Ui.vgap(10));
        String help = """
                How to connect an AI provider:
                1. Create an API key with your provider (for example OpenAI, or Anthropic for Claude).
                2. Click “Create config file”, open it, and replace PASTE_YOUR_API_KEY_HERE with your key.
                    For Anthropic also set  ai.provider=anthropic  in the same file.
                    (Alternative: set the environment variable AI_API_KEY and restart the app.)
                3. Come back here and click “Reload configuration”. No restart is needed for the config file.
                Your key stays on this computer and is only sent to your chosen provider.""";
        JLabel helpLabel = new JLabel("<html>" + Ui.escapeHtml(help) + "</html>");
        helpLabel.setFont(Theme.small());
        helpLabel.setForeground(Theme.MUTED);
        helpLabel.setAlignmentX(0f);
        body.add(helpLabel);
        body.add(Ui.vgap(12));

        ModernButton create = new ModernButton("Create config file", ModernButton.Kind.SECONDARY);
        create.addActionListener(e -> {
            try {
                boolean created = cfg.createTemplateIfMissing();
                Ui.message(this, created ? "Config file created" : "Config file already exists",
                        (created ? "A template was created at:\n" : "Your existing file was left untouched:\n") + cfg.configFile()
                                + "\n\nOpen it with any text editor, add your key, save it and click “Reload configuration”.", false);
                openFolder();
            } catch (IOException ex) {
                Ui.message(this, "Could not create the config file", ex.getMessage(), true);
            }
        });
        ModernButton open = new ModernButton("Open data folder", ModernButton.Kind.SECONDARY);
        open.addActionListener(e -> openFolder());
        ModernButton reload = new ModernButton("Reload configuration", ModernButton.Kind.PRIMARY);
        reload.addActionListener(e -> { cfg.reload(); onAiConfigChanged.run(); rebuild(); });
        body.add(buttons(create, open, reload));
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JComponent databaseCard() {
        RoundedPanel card = card("Database", "Everything is stored locally in a SQLite file");
        JPanel body = column();
        body.add(kv("Location", ctx.database.file().toAbsolutePath().toString()));
        try {
            body.add(kv("Size", String.format("%.1f KB", ctx.database.sizeBytes() / 1024.0)));
            body.add(kv("Tasks", String.valueOf(ctx.taskRepo.count(""))));
            body.add(kv("Notes", String.valueOf(ctx.noteRepo.count())));
            body.add(kv("Reminders", String.valueOf(ctx.reminderRepo.count())));
            body.add(kv("Conversations", ctx.chatRepo.countConversations() + " (" + ctx.chatRepo.countMessages() + " messages)"));
        } catch (RuntimeException e) {
            body.add(Ui.banner("Could not read database statistics: " + e.getMessage(), Theme.DANGER, Theme.DANGER_SOFT));
        }
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JComponent dataCard() {
        RoundedPanel card = card("Data management", "These actions ask for confirmation first");
        ModernButton backup = new ModernButton("Back up database…", ModernButton.Kind.SECONDARY);
        backup.addActionListener(e -> backup());
        ModernButton clearChats = new ModernButton("Clear chat history", ModernButton.Kind.DANGER);
        clearChats.addActionListener(e -> {
            if (!Ui.confirm(this, "Clear all chat history?", "All AI conversations and messages will be permanently deleted. Tasks, reminders and notes are not affected.", "Clear history", true)) return;
            try {
                ctx.chat.deleteAllHistory();
                Ui.message(this, "Chat history cleared", "All conversations were deleted.", false);
                rebuild();
            } catch (RuntimeException ex) {
                Ui.message(this, "Could not clear chat history", ex.getMessage(), true);
            }
        });
        ModernButton clearDone = new ModernButton("Delete completed tasks", ModernButton.Kind.DANGER);
        clearDone.addActionListener(e -> {
            int n = ctx.tasks.list(TaskFilter.COMPLETED, null).size();
            if (n == 0) { Ui.message(this, "Nothing to delete", "There are no completed tasks.", false); return; }
            if (!Ui.confirm(this, "Delete completed tasks?", n + " completed task(s) will be permanently deleted.", "Delete", true)) return;
            try {
                int deleted = ctx.tasks.deleteCompleted();
                Ui.message(this, "Done", deleted + " completed task(s) deleted.", false);
                rebuild();
            } catch (RuntimeException ex) {
                Ui.message(this, "Could not delete tasks", ex.getMessage(), true);
            }
        });
        card.add(buttons(backup, clearChats, clearDone), BorderLayout.CENTER);
        return card;
    }

    private JComponent aboutCard() {
        RoundedPanel card = card("About", null);
        JPanel body = column();
        body.add(kv("Application", AppConfig.APP_NAME + " " + AppConfig.APP_VERSION));
        body.add(kv("Java", System.getProperty("java.version") + " (" + System.getProperty("java.vendor") + ")"));
        body.add(kv("Operating system", System.getProperty("os.name") + " " + System.getProperty("os.version")));
        body.add(kv("Data folder", ctx.config.dataDir().toAbsolutePath().toString()));
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    // ------------------------------------------------------------------ actions

    private void openFolder() {
        try {
            Files.createDirectories(ctx.config.dataDir());
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(ctx.config.dataDir().toFile());
            } else {
                Ui.message(this, "Data folder", "Open this folder in your file manager:\n" + ctx.config.dataDir(), false);
            }
        } catch (IOException | RuntimeException e) {
            Ui.message(this, "Could not open the folder", "Open it manually:\n" + ctx.config.dataDir(), true);
        }
    }

    private void backup() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Save a copy of your database");
        fc.setSelectedFile(new File("assistant-backup-" + DateTimeFormatter.BASIC_ISO_DATE.format(LocalDate.now()) + ".db"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File target = fc.getSelectedFile();
        if (target.exists() && !Ui.confirm(this, "Replace file?", target.getName() + " already exists. Replace it?", "Replace", true)) return;
        try {
            Files.copy(ctx.database.file(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            Ui.message(this, "Backup saved", "Your data was copied to:\n" + target, false);
        } catch (IOException e) {
            Ui.message(this, "Backup failed", "Could not write the backup: " + e.getMessage(), true);
        }
    }
}
