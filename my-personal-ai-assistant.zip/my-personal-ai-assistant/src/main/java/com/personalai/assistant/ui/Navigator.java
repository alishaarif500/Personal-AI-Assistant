package com.personalai.assistant.ui;

/** Lets a page ask the main window to switch to another page. */
public interface Navigator {
    String DASHBOARD = "dashboard";
    String CHAT = "chat";
    String TASKS = "tasks";
    String REMINDERS = "reminders";
    String NOTES = "notes";
    String SETTINGS = "settings";

    void navigate(String pageId);
}
