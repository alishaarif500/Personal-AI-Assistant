package com.personalai.assistant.ai;

import com.personalai.assistant.model.ChatMessage;
import com.personalai.assistant.util.Json;

import java.util.List;
import java.util.Map;

/** Anthropic Messages API provider (set ai.provider=anthropic). */
public class AnthropicProvider implements AiProvider {
    private final String baseUrl;
    private final String apiKey;
    private final String model;

    public AnthropicProvider(String baseUrl, String apiKey, String model) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey == null ? "" : apiKey;
        this.model = model;
    }

    @Override public String id() { return "anthropic"; }
    @Override public String displayName() { return "Anthropic (" + model + ")"; }
    @Override public boolean isConfigured() { return !apiKey.isBlank(); }

    String buildBody(List<ChatMessage> history) {
        StringBuilder sb = new StringBuilder("{\"model\":").append(Json.quote(model))
                .append(",\"max_tokens\":1024,\"system\":").append(Json.quote(OpenAiCompatibleProvider.SYSTEM_PROMPT))
                .append(",\"messages\":[");
        boolean first = true;
        for (ChatMessage m : history) {
            if (!first) sb.append(',');
            first = false;
            sb.append("{\"role\":").append(Json.quote(m.role().wire()))
              .append(",\"content\":").append(Json.quote(m.content())).append('}');
        }
        return sb.append("]}").toString();
    }

    static String extractReply(Object parsed) throws AiException {
        Map<String, Object> root = Json.asObject(parsed);
        List<Object> content = root == null ? null : Json.asArray(root.get("content"));
        if (content != null) {
            StringBuilder out = new StringBuilder();
            for (Object block : content) {
                Map<String, Object> b = Json.asObject(block);
                if (b != null && "text".equals(b.get("type")) && b.get("text") instanceof String t) out.append(t);
            }
            if (!out.toString().isBlank()) return out.toString().strip();
        }
        throw new AiException("The AI provider answered, but the reply was empty or in an unexpected format.");
    }

    @Override
    public String complete(List<ChatMessage> history) throws AiException {
        if (!isConfigured()) throw new AiNotConfiguredException();
        Object parsed = HttpSupport.postJson(baseUrl + "/messages",
                Map.of("x-api-key", apiKey, "anthropic-version", "2023-06-01"), buildBody(history));
        return extractReply(parsed);
    }
}
