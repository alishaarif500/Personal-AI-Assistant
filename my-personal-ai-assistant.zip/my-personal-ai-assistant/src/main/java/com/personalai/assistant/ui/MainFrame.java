package com.personalai.assistant.ui;

import com.personalai.assistant.AppContext;
import com.personalai.assistant.config.AppConfig;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/** The main window: sidebar navigation on the left, the selected page on the right. */
public final class MainFrame extends JFrame implements Navigator {
    private final AppContext ctx;
    private final JPanel cards = new JPanel(new CardLayout());
    private final Map<String, NavButton> navButtons = new LinkedHashMap<>();
    private final Map<String, Page> pages = new LinkedHashMap<>();
    private final JLabel aiStatus = new JLabel();
    private final ReminderPanel reminderPanel;
    private final ChatPanel chatPanel;
    private String currentPage = DASHBOARD;

    public MainFrame(AppContext ctx, Consumer<Theme.Mode> themeSwitcher) {
        super(AppConfig.APP_NAME);
        this.ctx = ctx;
        setIconImage(createAppIcon());
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setMinimumSize(new Dimension(1040, 680));
        setSize(1260, 800);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Theme.BG);
        setLayout(new BorderLayout());

        add(buildSidebar(), BorderLayout.WEST);

        cards.setBackground(Theme.BG);
        cards.setOpaque(true);
        reminderPanel = new ReminderPanel(ctx.reminders);
        chatPanel = new ChatPanel(ctx.chat, this);
        register(DASHBOARD, new DashboardPanel(ctx.dashboard, this));
        register(CHAT, chatPanel);
        register(TASKS, new TaskPanel(ctx.tasks));
        register(REMINDERS, reminderPanel);
        register(NOTES, new NotesPanel(ctx.notes));
        register(SETTINGS, new SettingsPanel(ctx, themeSwitcher, this::refreshAiStatus));
        add(cards, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { shutdown(); }
        });
        refreshAiStatus();
        navigate(DASHBOARD);
    }

    private void register(String id, Component page) {
        cards.add(page, id);
        pages.put(id, (Page) page);
    }

    private JPanel buildSidebar() {
        JPanel side = new JPanel();
        side.setBackground(Theme.SIDEBAR);
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(BorderFactory.createEmptyBorder(24, 16, 18, 16));
        side.setPreferredSize(new Dimension(236, 100));

        JPanel brand = new JPanel(new BorderLayout(12, 0));
        brand.setOpaque(false);
        brand.setAlignmentX(0f);
        brand.setBorder(BorderFactory.createEmptyBorder(0, 6, 22, 0));
        brand.add(new JLabel(new javax.swing.ImageIcon(createAppIcon().getScaledInstance(38, 38, java.awt.Image.SCALE_SMOOTH))), BorderLayout.WEST);
        JPanel names = new JPanel();
        names.setOpaque(false);
        names.setLayout(new BoxLayout(names, BoxLayout.Y_AXIS));
        names.add(Ui.label("My Personal", Theme.font(java.awt.Font.BOLD, 15f), java.awt.Color.WHITE));
        names.add(Ui.label("AI Assistant", Theme.font(java.awt.Font.PLAIN, 13f), Theme.SIDEBAR_TEXT));
        brand.add(names, BorderLayout.CENTER);
        brand.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
        side.add(brand);

        addNav(side, DASHBOARD, "Dashboard", Icons.Type.DASHBOARD);
        addNav(side, CHAT, "AI Chat", Icons.Type.CHAT);
        addNav(side, TASKS, "Tasks", Icons.Type.TASKS);
        addNav(side, REMINDERS, "Reminders", Icons.Type.BELL);
        addNav(side, NOTES, "Notes", Icons.Type.NOTES);
        side.add(Box.createVerticalGlue());
        addNav(side, SETTINGS, "Settings", Icons.Type.SETTINGS);
        side.add(Ui.vgap(14));
        aiStatus.setFont(Theme.small());
        aiStatus.setAlignmentX(0f);
        aiStatus.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));
        side.add(aiStatus);
        return side;
    }

    private void addNav(JPanel side, String id, String text, Icons.Type icon) {
        NavButton b = new NavButton(text, icon);
        b.setAlignmentX(0f);
        b.addActionListener(e -> navigate(id));
        navButtons.put(id, b);
        side.add(b);
        side.add(Ui.vgap(4));
    }

    @Override public void navigate(String pageId) {
        if (!pages.containsKey(pageId)) return;
        currentPage = pageId;
        navButtons.forEach((id, b) -> b.setActive(id.equals(pageId)));
        pages.get(pageId).onShow();
        ((CardLayout) cards.getLayout()).show(cards, pageId);
        refreshAiStatus();
    }

    private void refreshAiStatus() {
        boolean ok = ctx.config.isAiConfigured();
        aiStatus.setText((ok ? "●  AI ready" : "●  AI not configured"));
        aiStatus.setForeground(ok ? new java.awt.Color(0x34D399) : new java.awt.Color(0xFBBF24));
    }

    /** Starts the background reminder check. Pop-ups appear even if another page is open. */
    public void startReminders() {
        ctx.reminders.start(r -> SwingUtilities.invokeLater(() -> {
            ToastNotification.show(this, r);
            reminderPanel.refresh();
            if (DASHBOARD.equals(currentPage)) pages.get(DASHBOARD).onShow();
        }), 10);
    }

    public void stopBackgroundWork() { ctx.reminders.stop(); }

    private void shutdown() {
        stopBackgroundWork();
        dispose();
        System.exit(0);
    }

    static BufferedImage createAppIcon() {
        int s = 128;
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(new java.awt.GradientPaint(0, 0, new java.awt.Color(0x6366F1), s, s, new java.awt.Color(0x4338CA)));
        g.fillRoundRect(0, 0, s, s, 36, 36);
        Icons.paint((Graphics2D) g.create(), Icons.Type.SPARK, 30, 30, 68, java.awt.Color.WHITE);
        g.dispose();
        return img;
    }
}
