package com.personalai.assistant.ui;

import javax.swing.JComponent;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Round check box used for completing tasks. */
public class CheckCircle extends JComponent {
    private final boolean checked;
    private boolean hover;

    public CheckCircle(boolean checked, Runnable onClick) {
        this.checked = checked;
        setPreferredSize(new Dimension(28, 28));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setToolTipText(checked ? "Mark as pending" : "Mark as completed");
        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
            @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            @Override public void mouseClicked(MouseEvent e) { onClick.run(); }
        });
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int d = 22, x = (getWidth() - d) / 2, y = (getHeight() - d) / 2;
        if (checked) {
            g2.setColor(Theme.SUCCESS);
            g2.fillOval(x, y, d, d);
            Icons.paint(g2, Icons.Type.CHECK, x + 3, y + 3, 16, java.awt.Color.WHITE);
        } else {
            g2.setColor(hover ? Theme.SUCCESS : Theme.BORDER);
            g2.setStroke(new java.awt.BasicStroke(2f));
            g2.drawOval(x, y, d, d);
            if (hover) Icons.paint(g2, Icons.Type.CHECK, x + 3, y + 3, 16, Theme.SUCCESS);
        }
        g2.dispose();
    }
}
