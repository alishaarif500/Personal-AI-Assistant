package com.personalai.assistant.ai;

/** Any problem while talking to the AI provider; the message is safe to show to the user. */
public class AiException extends Exception {
    public AiException(String message) { super(message); }
    public AiException(String message, Throwable cause) { super(message, cause); }
}
