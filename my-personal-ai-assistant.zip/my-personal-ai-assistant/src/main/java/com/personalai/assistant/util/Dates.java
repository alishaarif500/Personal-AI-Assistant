package com.personalai.assistant.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Date/time formatting helpers used across the UI. */
public final class Dates {
    private Dates() {}

    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm", Locale.ENGLISH);
    public static final DateTimeFormatter LONG_DATE = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH);
    public static final DateTimeFormatter TIME_SECONDS = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ENGLISH);

    public static String date(LocalDate d) { return d == null ? "" : DATE.format(d); }
    public static String dateTime(LocalDateTime d) { return d == null ? "" : DATE_TIME.format(d); }

    /** "Today, 14:30", "Tomorrow, 09:00" or "12 Nov 2026, 09:00". */
    public static String friendly(LocalDateTime dt, LocalDate today) {
        if (dt == null) return "";
        if (dt.toLocalDate().equals(today)) return "Today, " + TIME.format(dt);
        if (dt.toLocalDate().equals(today.plusDays(1))) return "Tomorrow, " + TIME.format(dt);
        return DATE_TIME.format(dt);
    }

    public static String greeting(LocalDateTime now) {
        int h = now.getHour();
        if (h < 12) return "Good morning";
        if (h < 18) return "Good afternoon";
        return "Good evening";
    }
}
