package com.personalai.assistant;

import com.personalai.assistant.config.AppConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AppConfigTest {
    @Test
    void notConfiguredByDefault(@TempDir Path dir) {
        AppConfig c = new AppConfig(dir, Map.of());
        assertFalse(c.isAiConfigured());
        assertEquals("(none)", c.maskedKey());
        assertEquals("openai", c.provider());
    }

    @Test
    void templateKeyPlaceholderCountsAsNotConfigured(@TempDir Path dir) throws Exception {
        AppConfig c = new AppConfig(dir, Map.of());
        assertTrue(c.createTemplateIfMissing());
        assertFalse(c.createTemplateIfMissing(), "must not overwrite an existing file");
        c.reload();
        assertFalse(c.isAiConfigured());
    }

    @Test
    void readsFileAndReloads(@TempDir Path dir) throws Exception {
        AppConfig c = new AppConfig(dir, Map.of());
        Files.writeString(c.configFile(), "ai.api.key=sk-test-1234567890\nai.provider=anthropic\n");
        c.reload();
        assertTrue(c.isAiConfigured());
        assertEquals("anthropic", c.provider());
        assertEquals("https://api.anthropic.com/v1", c.baseUrl());
        assertFalse(c.maskedKey().contains("test-12345"));
        assertEquals("config.properties", c.apiKeySource());
    }

    @Test
    void environmentOverridesFile(@TempDir Path dir) throws Exception {
        Files.createDirectories(dir);
        Files.writeString(dir.resolve("config.properties"), "ai.api.key=file-key-abcdefgh\nai.model=file-model\n");
        AppConfig c = new AppConfig(dir, Map.of("AI_API_KEY", "env-key-abcdefgh", "AI_MODEL", "env-model", "AI_BASE_URL", "http://localhost:1234/v1/"));
        assertEquals("env-key-abcdefgh", c.apiKey());
        assertEquals("env-model", c.model());
        assertEquals("http://localhost:1234/v1", c.baseUrl());
        assertTrue(c.apiKeySource().contains("environment"));
    }
}
