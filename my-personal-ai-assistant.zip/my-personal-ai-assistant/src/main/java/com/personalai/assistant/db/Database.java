package com.personalai.assistant.db;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * SQLite connection management and schema creation.
 * One short-lived connection per operation keeps things simple and safe; SQLite handles this very well.
 */
public final class Database {
    static {
        try {
            Class.forName("org.sqlite.JDBC"); // registers the driver explicitly (robust in fat jars and test runners)
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("SQLite JDBC driver is missing from the classpath");
        }
    }

    private final Path file;
    private final String url;

    public Database(Path file) {
        this.file = file;
        this.url = "jdbc:sqlite:" + file.toAbsolutePath();
    }

    public Path file() { return file; }

    /** Id of the row inserted last on this connection (portable replacement for getGeneratedKeys). */
    public static long lastInsertId(Connection c) throws SQLException {
        try (Statement st = c.createStatement(); java.sql.ResultSet rs = st.executeQuery("SELECT last_insert_rowid()")) {
            rs.next();
            return rs.getLong(1);
        }
    }

    public Connection connect() {
        try {
            Connection c = DriverManager.getConnection(url);
            try (Statement st = c.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
                st.execute("PRAGMA busy_timeout = 5000");
            }
            return c;
        } catch (SQLException e) {
            throw new DatabaseException("Could not open the database at " + file + ": " + e.getMessage(), e);
        }
    }

    /** Creates the data folder, the database file and all tables on first launch. Safe to call repeatedly. */
    public void initialize() {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
        } catch (IOException e) {
            throw new DatabaseException("Could not create the data folder: " + e.getMessage(), e);
        }
        try (Connection c = connect(); Statement st = c.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    title        TEXT NOT NULL,
                    description  TEXT NOT NULL DEFAULT '',
                    priority     TEXT NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('LOW','MEDIUM','HIGH')),
                    due_date     TEXT,
                    created_at   TEXT NOT NULL,
                    status       TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','COMPLETED')),
                    completed_at TEXT
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS notes (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    title      TEXT NOT NULL,
                    content    TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS reminders (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    title       TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    remind_at   TEXT NOT NULL,
                    notified    INTEGER NOT NULL DEFAULT 0 CHECK (notified IN (0,1)),
                    created_at  TEXT NOT NULL
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    title      TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
                    role            TEXT NOT NULL CHECK (role IN ('user','assistant')),
                    content         TEXT NOT NULL,
                    created_at      TEXT NOT NULL
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key   TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )""");
            st.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status, due_date)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(notified, remind_at)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, id)");
        } catch (SQLException e) {
            throw new DatabaseException("Could not initialise the database: " + e.getMessage(), e);
        }
    }

    public long sizeBytes() {
        try {
            return Files.exists(file) ? Files.size(file) : 0;
        } catch (IOException e) {
            return 0;
        }
    }
}
