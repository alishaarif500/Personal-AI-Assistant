package com.personalai.assistant.db;

/** Unchecked wrapper for database failures so the UI can show a clear message. */
public class DatabaseException extends RuntimeException {
    public DatabaseException(String message, Throwable cause) { super(message, cause); }
}
