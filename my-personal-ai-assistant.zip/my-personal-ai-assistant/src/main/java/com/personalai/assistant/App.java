package com.personalai.assistant;

import com.personalai.assistant.config.AppConfig;
import com.personalai.assistant.ui.MainFrame;
import com.personalai.assistant.ui.Theme;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;
import java.awt.Point;
import java.awt.Dimension;
import java.util.Enumeration;

/** Application entry point. */
public final class App {
    private static AppContext context;
    private static MainFrame frame;

    private App() {}

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        try {
            context = new AppContext(AppConfig.forCurrentUser());
        } catch (RuntimeException e) {
            String msg = "My Personal AI Assistant could not start because the database is not available.\n\n" + e.getMessage();
            System.err.println(msg);
            try {
                JOptionPane.showMessageDialog(null, msg, "Startup problem", JOptionPane.ERROR_MESSAGE);
            } catch (java.awt.HeadlessException ignored) { /* console message above is enough */ }
            System.exit(1);
            return;
        }
        SwingUtilities.invokeLater(() -> {
            installLookAndFeel();
            Theme.apply(loadSavedTheme());
            applyDefaultFonts();
            showWindow(null, null);
        });
    }

    private static Theme.Mode loadSavedTheme() {
        try {
            return Theme.Mode.valueOf(context.settings.get("theme", "LIGHT"));
        } catch (RuntimeException e) {
            return Theme.Mode.LIGHT;
        }
    }

    private static void showWindow(Point location, Dimension size) {
        frame = new MainFrame(context, App::switchTheme);
        if (location != null) frame.setLocation(location);
        if (size != null) frame.setSize(size);
        frame.setVisible(true);
        frame.startReminders();
    }

    /** Re-creates the window with the new colours (all colours are read when widgets are created). */
    private static void switchTheme(Theme.Mode mode) {
        try {
            context.settings.set("theme", mode.name());
        } catch (RuntimeException e) {
            System.err.println("Could not save theme: " + e.getMessage());
        }
        Theme.apply(mode);
        MainFrame old = frame;
        Point loc = old.getLocation();
        Dimension size = old.getSize();
        old.stopBackgroundWork();
        old.dispose();
        showWindow(loc, size);
        frame.navigate(MainFrame.SETTINGS);
    }

    private static void installLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {
            // The default look and feel is fine as a fallback.
        }
    }

    private static void applyDefaultFonts() {
        FontUIResource f = new FontUIResource(Theme.base());
        Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            if (UIManager.get(key) instanceof FontUIResource) UIManager.put(key, f);
        }
    }
}
