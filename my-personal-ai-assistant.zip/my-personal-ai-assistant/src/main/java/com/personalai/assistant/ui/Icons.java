package com.personalai.assistant.ui;

import javax.swing.Icon;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

/** Small vector icons drawn with Java2D (no image files needed, crisp at any scale). */
public final class Icons {
    public enum Type { DASHBOARD, CHAT, TASKS, BELL, NOTES, SETTINGS, PLUS, TRASH, EDIT, CHECK, SEARCH, SEND, CLOCK, CALENDAR, SPARK }

    private Icons() {}

    public static Icon of(Type type, int size, Color color) {
        return new Icon() {
            @Override public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                paint(g2, type, x, y, size, color);
                g2.dispose();
            }
            @Override public int getIconWidth() { return size; }
            @Override public int getIconHeight() { return size; }
        };
    }

    public static void paint(Graphics2D g, Type type, int x, int y, int s, Color color) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.translate(x, y);
        g.scale(s, s);
        g.setColor(color);
        g.setStroke(new BasicStroke(Math.max(1.5f, s / 11f) / s, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (type) {
            case DASHBOARD -> {
                double a = 0.34, o = 0.12, p = 0.54;
                g.draw(new RoundRectangle2D.Double(o, o, a, a, 0.1, 0.1));
                g.draw(new RoundRectangle2D.Double(p, o, a, a, 0.1, 0.1));
                g.draw(new RoundRectangle2D.Double(o, p, a, a, 0.1, 0.1));
                g.draw(new RoundRectangle2D.Double(p, p, a, a, 0.1, 0.1));
            }
            case CHAT -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.18, 0.14); p.lineTo(0.82, 0.14);
                p.quadTo(0.9, 0.14, 0.9, 0.22); p.lineTo(0.9, 0.58);
                p.quadTo(0.9, 0.66, 0.82, 0.66); p.lineTo(0.42, 0.66);
                p.lineTo(0.24, 0.84); p.lineTo(0.24, 0.66); p.lineTo(0.18, 0.66);
                p.quadTo(0.1, 0.66, 0.1, 0.58); p.lineTo(0.1, 0.22);
                p.quadTo(0.1, 0.14, 0.18, 0.14); p.closePath();
                g.draw(p);
            }
            case TASKS -> {
                g.draw(new Ellipse2D.Double(0.1, 0.1, 0.8, 0.8));
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.3, 0.52); p.lineTo(0.45, 0.67); p.lineTo(0.72, 0.36);
                g.draw(p);
            }
            case BELL -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.2, 0.72); p.lineTo(0.26, 0.64); p.lineTo(0.26, 0.45);
                p.curveTo(0.26, 0.2, 0.74, 0.2, 0.74, 0.45); p.lineTo(0.74, 0.64); p.lineTo(0.8, 0.72); p.closePath();
                g.draw(p);
                g.draw(new Arc2D.Double(0.4, 0.74, 0.2, 0.16, 180, 180, Arc2D.OPEN));
                g.draw(new Line2D.Double(0.5, 0.14, 0.5, 0.22));
            }
            case NOTES -> {
                g.draw(new RoundRectangle2D.Double(0.2, 0.1, 0.6, 0.8, 0.1, 0.1));
                g.draw(new Line2D.Double(0.33, 0.33, 0.67, 0.33));
                g.draw(new Line2D.Double(0.33, 0.5, 0.67, 0.5));
                g.draw(new Line2D.Double(0.33, 0.67, 0.5, 0.67));
            }
            case SETTINGS -> {
                g.draw(new Ellipse2D.Double(0.32, 0.32, 0.36, 0.36));
                for (int i = 0; i < 8; i++) {
                    double ang = Math.toRadians(i * 45);
                    g.draw(new Line2D.Double(0.5 + Math.cos(ang) * 0.27, 0.5 + Math.sin(ang) * 0.27,
                            0.5 + Math.cos(ang) * 0.4, 0.5 + Math.sin(ang) * 0.4));
                }
                g.draw(new Ellipse2D.Double(0.2, 0.2, 0.6, 0.6));
            }
            case PLUS -> {
                g.draw(new Line2D.Double(0.5, 0.2, 0.5, 0.8));
                g.draw(new Line2D.Double(0.2, 0.5, 0.8, 0.5));
            }
            case TRASH -> {
                g.draw(new Line2D.Double(0.15, 0.25, 0.85, 0.25));
                g.draw(new Line2D.Double(0.38, 0.25, 0.38, 0.14));
                g.draw(new Line2D.Double(0.38, 0.14, 0.62, 0.14));
                g.draw(new Line2D.Double(0.62, 0.14, 0.62, 0.25));
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.24, 0.25); p.lineTo(0.29, 0.86); p.lineTo(0.71, 0.86); p.lineTo(0.76, 0.25);
                g.draw(p);
                g.draw(new Line2D.Double(0.42, 0.4, 0.42, 0.7));
                g.draw(new Line2D.Double(0.58, 0.4, 0.58, 0.7));
            }
            case EDIT -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.18, 0.82); p.lineTo(0.26, 0.56); p.lineTo(0.68, 0.14); p.lineTo(0.86, 0.32);
                p.lineTo(0.44, 0.74); p.closePath();
                g.draw(p);
                g.draw(new Line2D.Double(0.58, 0.24, 0.76, 0.42));
            }
            case CHECK -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.2, 0.54); p.lineTo(0.42, 0.74); p.lineTo(0.8, 0.28);
                g.draw(p);
            }
            case SEARCH -> {
                g.draw(new Ellipse2D.Double(0.14, 0.14, 0.5, 0.5));
                g.draw(new Line2D.Double(0.6, 0.6, 0.85, 0.85));
            }
            case SEND -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.1, 0.48); p.lineTo(0.9, 0.12); p.lineTo(0.62, 0.88); p.lineTo(0.48, 0.58); p.closePath();
                g.draw(p);
                g.draw(new Line2D.Double(0.48, 0.58, 0.9, 0.12));
            }
            case CLOCK -> {
                g.draw(new Ellipse2D.Double(0.1, 0.1, 0.8, 0.8));
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.5, 0.28); p.lineTo(0.5, 0.52); p.lineTo(0.66, 0.62);
                g.draw(p);
            }
            case CALENDAR -> {
                g.draw(new RoundRectangle2D.Double(0.12, 0.18, 0.76, 0.68, 0.1, 0.1));
                g.draw(new Line2D.Double(0.12, 0.38, 0.88, 0.38));
                g.draw(new Line2D.Double(0.32, 0.1, 0.32, 0.26));
                g.draw(new Line2D.Double(0.68, 0.1, 0.68, 0.26));
            }
            case SPARK -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(0.5, 0.08); p.quadTo(0.55, 0.45, 0.92, 0.5); p.quadTo(0.55, 0.55, 0.5, 0.92);
                p.quadTo(0.45, 0.55, 0.08, 0.5); p.quadTo(0.45, 0.45, 0.5, 0.08); p.closePath();
                g.fill(p);
            }
        }
    }
}
