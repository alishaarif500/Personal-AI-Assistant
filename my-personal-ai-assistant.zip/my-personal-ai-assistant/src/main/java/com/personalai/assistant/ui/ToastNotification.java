package com.personalai.assistant.ui;

import com.personalai.assistant.model.Reminder;
import com.personalai.assistant.util.Dates;
import com.personalai.assistant.util.Text;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.BoxLayout;
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.Window;
import java.util.ArrayList;
import java.util.List;

/** Non-blocking pop-up shown in the bottom-right corner when a reminder is due. Must be used on the EDT. */
public final class ToastNotification {
    private static final List<JDialog> OPEN = new ArrayList<>();

    private ToastNotification() {}

    public static void show(Window owner, Reminder r) {
        if (GraphicsEnvironment.isHeadless()) return;
        try { Toolkit.getDefaultToolkit().beep(); } catch (Exception ignored) { /* no sound device */ }
        JDialog d = new JDialog(owner);
        d.setUndecorated(true);
        d.setAlwaysOnTop(true);
        d.setFocusableWindowState(false);

        RoundedPanel card = new RoundedPanel(new BorderLayout(14, 0), Theme.SURFACE, Theme.ACCENT, 16);
        card.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
        javax.swing.JComponent bell = new JLabel(Icons.of(Icons.Type.BELL, 30, Theme.ACCENT));
        card.add(bell, BorderLayout.WEST);
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        JLabel head = Ui.label("Reminder", Theme.smallBold(), Theme.ACCENT);
        JLabel title = Ui.label(Text.truncate(r.title(), 42), Theme.bold(), Theme.TEXT);
        text.add(head);
        text.add(title);
        if (!r.description().isBlank()) text.add(Ui.label(Text.truncate(r.description(), 52), Theme.small(), Theme.MUTED));
        text.add(Ui.label(Dates.dateTime(r.remindAt()), Theme.small(), Theme.MUTED));
        card.add(text, BorderLayout.CENTER);
        ModernButton dismiss = new ModernButton("Dismiss", ModernButton.Kind.SECONDARY);
        dismiss.addActionListener(e -> close(d));
        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(dismiss, BorderLayout.EAST);
        south.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        card.add(south, BorderLayout.SOUTH);
        d.setContentPane(card);
        d.pack();
        d.setSize(Math.max(340, d.getWidth()), d.getHeight());

        Rectangle screen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int offset = 0;
        for (JDialog o : OPEN) offset += o.getHeight() + 10;
        d.setLocation(screen.x + screen.width - d.getWidth() - 20, screen.y + screen.height - d.getHeight() - 20 - offset);
        OPEN.add(d);
        d.setVisible(true);
        Timer t = new Timer(45_000, e -> close(d));
        t.setRepeats(false);
        t.start();
    }

    private static void close(JDialog d) {
        OPEN.remove(d);
        d.dispose();
    }
}
