package com.personalai.assistant;

import com.personalai.assistant.model.Priority;
import com.personalai.assistant.model.TaskFilter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/** Simulates closing and reopening the application: data must survive. */
class PersistenceTest {
    @Test
    void dataSurvivesRestart(@TempDir Path dir) {
        AppContext first = TestSupport.newContext(dir);
        first.tasks.create("Persistent task", "desc", Priority.HIGH, null);
        first.notes.create("Persistent note", "body");
        first.reminders.create("Persistent reminder", "", LocalDateTime.now().plusDays(1));
        long conv = first.chat.newConversation().id();
        first.chat.saveUserMessage(conv, "remember me");
        first.settings.set("theme", "DARK");

        AppContext second = TestSupport.newContext(dir); // new objects, same files
        assertEquals("Persistent task", second.tasks.list(TaskFilter.ALL, null).get(0).title());
        assertEquals("Persistent note", second.notes.search(null).get(0).title());
        assertEquals("Persistent reminder", second.reminders.listAll().get(0).title());
        assertEquals("remember me", second.chat.messages(conv).get(0).content());
        assertEquals("DARK", second.settings.get("theme", "LIGHT"));
    }

    @Test
    void dashboardReflectsDatabase(@TempDir Path dir) {
        AppContext ctx = TestSupport.newContext(dir);
        var t = ctx.tasks.create("A", "", Priority.MEDIUM, java.time.LocalDate.now());
        ctx.tasks.create("B", "", Priority.MEDIUM, null);
        ctx.tasks.setCompleted(t.id(), true);
        var snap = ctx.dashboard.load();
        assertEquals(2, snap.totalTasks());
        assertEquals(1, snap.pendingTasks());
        assertEquals(1, snap.completedTasks());
        assertEquals(50, snap.completionPercent());
        assertEquals(1, snap.todayTasks().size());
        assertEquals(1, snap.completedLast7Days().get(java.time.LocalDate.now()));
        assertEquals(7, snap.completedLast7Days().size());
    }
}
