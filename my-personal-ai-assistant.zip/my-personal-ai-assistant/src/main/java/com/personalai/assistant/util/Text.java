package com.personalai.assistant.util;

/** Small text helpers. */
public final class Text {
    private Text() {}

    public static String trimToNull(String s) {
        if (s == null) return null;
        String t = s.strip();
        return t.isEmpty() ? null : t;
    }

    public static String truncate(String s, int max) {
        if (s == null) return "";
        String one = s.replaceAll("\\s+", " ").strip();
        return one.length() <= max ? one : one.substring(0, Math.max(0, max - 1)).stripTrailing() + "…";
    }

    /** Escapes % _ \ for use in SQL LIKE ... ESCAPE '\'. */
    public static String likeEscape(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }
}
