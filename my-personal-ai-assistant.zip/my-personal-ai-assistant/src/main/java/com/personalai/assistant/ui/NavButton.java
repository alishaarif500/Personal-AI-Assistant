package com.personalai.assistant.ui;

import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Sidebar navigation entry. */
class NavButton extends JButton {
    private final Icons.Type icon;
    private boolean active;
    private boolean hover;

    NavButton(String text, Icons.Type icon) {
        super(text);
        this.icon = icon;
        setFont(Theme.font(java.awt.Font.BOLD, 14f));
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setHorizontalAlignment(LEFT);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setPreferredSize(new Dimension(200, 44));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
            @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
        });
    }

    void setActive(boolean a) { active = a; repaint(); }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        if (active || hover) {
            g2.setColor(active ? Theme.SIDEBAR_ACTIVE : Theme.SIDEBAR_HOVER);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
        }
        java.awt.Color fg = active ? java.awt.Color.WHITE : Theme.SIDEBAR_TEXT;
        Icons.paint((Graphics2D) g2.create(), icon, 14, (getHeight() - 20) / 2, 20, fg);
        g2.setFont(getFont());
        g2.setColor(fg);
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(getText(), 46, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
        g2.dispose();
    }
}
