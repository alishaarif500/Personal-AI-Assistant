package com.personalai.assistant.ui;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Small square icon-only button (edit, delete, ...). */
public class IconButton extends JButton {
    private final Icons.Type type;
    private final Color hoverColor;
    private boolean hover;

    public IconButton(Icons.Type type, String tooltip, Color hoverColor) {
        this.type = type;
        this.hoverColor = hoverColor;
        setToolTipText(tooltip);
        getAccessibleContext().setAccessibleName(tooltip);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setPreferredSize(new Dimension(34, 34));
        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
            @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
        });
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (hover) {
            g2.setColor(Theme.SURFACE_ALT);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
        }
        Icons.paint(g2, type, (getWidth() - 18) / 2, (getHeight() - 18) / 2, 18, hover ? hoverColor : Theme.MUTED);
        g2.dispose();
    }
}
