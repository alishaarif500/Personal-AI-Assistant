@echo off
REM Double-click launcher for My Personal AI Assistant (Windows).
REM Requires JDK 17+ and Apache Maven on PATH. See README.md.
cd /d "%~dp0"
where java >nul 2>nul || (echo Java was not found. Install JDK 17 - see README.md & pause & exit /b 1)
where mvn  >nul 2>nul || (echo Maven was not found. Install it - see README.md & pause & exit /b 1)
call mvn -q compile exec:java
if errorlevel 1 pause
