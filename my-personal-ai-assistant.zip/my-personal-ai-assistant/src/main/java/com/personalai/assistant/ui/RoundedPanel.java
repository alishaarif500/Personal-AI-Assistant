package com.personalai.assistant.ui;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.RenderingHints;

/** A panel with rounded corners, an optional fill and an optional 1px border. */
public class RoundedPanel extends JPanel {
    private Color fill;
    private Color line;
    private int arc;

    public RoundedPanel(LayoutManager layout, Color fill, Color line, int arc) {
        super(layout);
        this.fill = fill;
        this.line = line;
        this.arc = arc;
        setOpaque(false);
    }

    public RoundedPanel(LayoutManager layout) { this(layout, Theme.SURFACE, Theme.BORDER, 16); }

    public void setFill(Color c) { this.fill = c; repaint(); }
    public void setLine(Color c) { this.line = c; repaint(); }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (fill != null) {
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
        }
        if (line != null) {
            g2.setColor(line);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
